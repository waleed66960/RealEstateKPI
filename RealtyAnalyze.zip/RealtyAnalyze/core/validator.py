"""Data validation utilities"""

import pandas as pd
import numpy as np
from typing import Dict, List, Any
from config.settings import AVAILABLE_KPIS

class DataValidator:
    """Validator class for input data"""
    
    def __init__(self):
        self.errors = []
        self.warnings = []
    
    def validate_uploaded_data(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Validate uploaded file data"""
        
        self.errors = []
        self.warnings = []
        
        # Basic validations
        if data.empty:
            self.errors.append("Data file is empty")
            return {'valid': False, 'errors': self.errors, 'warnings': self.warnings}
        
        # Check for required columns (at least one set of KPI fields should be present)
        available_columns = set(data.columns)
        
        # Check if we can calculate at least one KPI
        can_calculate_kpi = False
        for kpi, kpi_info in AVAILABLE_KPIS.items():
            required_fields = set(kpi_info['required_fields'])
            if required_fields.issubset(available_columns):
                can_calculate_kpi = True
                break
        
        if not can_calculate_kpi:
            self.errors.append("Data does not contain sufficient columns to calculate any KPIs")
            all_possible_fields = set()
            for kpi_info in AVAILABLE_KPIS.values():
                all_possible_fields.update(kpi_info['required_fields'])
            self.errors.append(f"Expected columns: {', '.join(all_possible_fields)}")
            self.errors.append(f"Found columns: {', '.join(data.columns)}")
        
        # Validate data types and values
        self._validate_numeric_columns(data)
        self._validate_value_ranges(data)
        self._check_missing_values(data)
        
        return {
            'valid': len(self.errors) == 0,
            'errors': self.errors,
            'warnings': self.warnings
        }
    
    def validate_manual_data(self, data: pd.DataFrame, required_fields: List[str]) -> Dict[str, Any]:
        """Validate manually entered data"""
        
        self.errors = []
        self.warnings = []
        
        # Check if all required fields are present
        missing_fields = [field for field in required_fields if field not in data.columns]
        if missing_fields:
            self.errors.append(f"Missing required fields: {', '.join(missing_fields)}")
        
        # Validate data values
        self._validate_numeric_columns(data)
        self._validate_value_ranges(data)
        self._check_all_zeros(data)
        
        return {
            'valid': len(self.errors) == 0,
            'errors': self.errors,
            'warnings': self.warnings
        }
    
    def validate_kpi_requirements(self, data: pd.DataFrame, selected_kpis: List[str]) -> Dict[str, Any]:
        """Validate that data contains required fields for selected KPIs"""
        
        self.errors = []
        self.warnings = []
        
        available_columns = set(data.columns)
        
        for kpi in selected_kpis:
            if kpi in AVAILABLE_KPIS:
                required_fields = set(AVAILABLE_KPIS[kpi]['required_fields'])
                missing_fields = required_fields - available_columns
                
                if missing_fields:
                    kpi_name = AVAILABLE_KPIS[kpi]['name_en']
                    self.errors.append(f"KPI '{kpi_name}' requires missing fields: {', '.join(missing_fields)}")
        
        return {
            'valid': len(self.errors) == 0,
            'errors': self.errors,
            'warnings': self.warnings
        }
    
    def _validate_numeric_columns(self, data: pd.DataFrame):
        """Validate that numeric columns contain valid numbers"""
        
        numeric_columns = ['TotalIncome', 'Expenses', 'PropertyValue', 'PropertyAge', 'AnnualGrowthRate']
        
        for col in numeric_columns:
            if col in data.columns:
                # Check for non-numeric values
                try:
                    pd.to_numeric(data[col], errors='raise')
                except (ValueError, TypeError):
                    self.errors.append(f"Column '{col}' contains non-numeric values")
                
                # Check for negative values where not allowed
                if col in ['TotalIncome', 'Expenses', 'PropertyValue', 'PropertyAge']:
                    negative_values = data[col] < 0
                    if negative_values.any():
                        self.errors.append(f"Column '{col}' contains negative values")
    
    def _validate_value_ranges(self, data: pd.DataFrame):
        """Validate that values are within reasonable ranges"""
        
        # Property Value validation
        if 'PropertyValue' in data.columns:
            very_low_values = data['PropertyValue'] < 1000
            very_high_values = data['PropertyValue'] > 100000000
            
            if very_low_values.any():
                self.warnings.append("Some property values appear unusually low (< $1,000)")
            
            if very_high_values.any():
                self.warnings.append("Some property values appear unusually high (> $100M)")
        
        # Property Age validation
        if 'PropertyAge' in data.columns:
            invalid_age = (data['PropertyAge'] < 0) | (data['PropertyAge'] > 200)
            if invalid_age.any():
                self.errors.append("Property age must be between 0 and 200 years")
        
        # Annual Growth Rate validation
        if 'AnnualGrowthRate' in data.columns:
            extreme_growth = (data['AnnualGrowthRate'] < -50) | (data['AnnualGrowthRate'] > 100)
            if extreme_growth.any():
                self.warnings.append("Some annual growth rates appear extreme (< -50% or > 100%)")
        
        # Income vs Expenses validation
        if 'TotalIncome' in data.columns and 'Expenses' in data.columns:
            expenses_exceed_income = data['Expenses'] > data['TotalIncome']
            if expenses_exceed_income.any():
                self.warnings.append("Expenses exceed income for some properties (negative NOI)")
    
    def _check_missing_values(self, data: pd.DataFrame):
        """Check for missing values"""
        
        missing_counts = data.isnull().sum()
        
        for col, count in missing_counts.items():
            if count > 0:
                percentage = (count / len(data)) * 100
                if percentage > 50:
                    self.errors.append(f"Column '{col}' has {percentage:.1f}% missing values")
                elif percentage > 20:
                    self.warnings.append(f"Column '{col}' has {percentage:.1f}% missing values")
    
    def _check_all_zeros(self, data: pd.DataFrame):
        """Check for columns with all zero values"""
        
        for col in data.columns:
            if data[col].dtype in ['int64', 'float64']:
                if (data[col] == 0).all():
                    self.warnings.append(f"Column '{col}' contains all zero values")
    
    def get_data_quality_score(self, data: pd.DataFrame) -> float:
        """Calculate a data quality score (0-100)"""
        
        if data.empty:
            return 0.0
        
        score = 100.0
        
        # Deduct points for missing values
        missing_percentage = (data.isnull().sum().sum() / (len(data) * len(data.columns))) * 100
        score -= missing_percentage
        
        # Deduct points for validation errors
        validation_result = self.validate_uploaded_data(data)
        error_count = len(validation_result['errors'])
        warning_count = len(validation_result['warnings'])
        
        score -= (error_count * 10)  # 10 points per error
        score -= (warning_count * 5)  # 5 points per warning
        
        return max(0.0, min(100.0, score))
