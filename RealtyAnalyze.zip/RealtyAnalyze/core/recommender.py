"""Investment recommendation engine"""

from typing import Dict, List, Any
from utils.localization import get_text
from config.settings import CAP_RATE_THRESHOLDS

class InvestmentRecommender:
    """Generate investment recommendations based on analysis results"""
    
    def __init__(self):
        self.recommendations = []
    
    def generate_recommendations(self, results: Dict[str, Any], selected_kpis: List[str]) -> List[Dict[str, str]]:
        """Generate comprehensive investment recommendations"""
        
        self.recommendations = []
        
        # Cap Rate based recommendations
        if 'cap_rate' in results and results['cap_rate']['status'] == 'success':
            self._analyze_cap_rate(results['cap_rate'])
        
        # NOI based recommendations
        if 'noi' in results and results['noi']['status'] == 'success':
            self._analyze_noi(results['noi'])
        
        # Opportunity Cost recommendations
        if 'opportunity_cost' in results and results['opportunity_cost']['status'] == 'success':
            self._analyze_opportunity_cost(results['opportunity_cost'])
        
        # Property Age recommendations
        if 'avg_property_age' in results and results['avg_property_age']['status'] == 'success':
            self._analyze_property_age(results['avg_property_age'])
        
        # Growth Rate recommendations
        if 'annual_growth_rate' in results and results['annual_growth_rate']['status'] == 'success':
            self._analyze_growth_rate(results['annual_growth_rate'])
        
        # Combined analysis recommendations
        self._generate_combined_recommendations(results, selected_kpis)
        
        return self.recommendations
    
    def _analyze_cap_rate(self, cap_rate_result: Dict[str, Any]):
        """Analyze capitalization rate and provide recommendations"""
        
        cap_rate = cap_rate_result['value']
        
        if cap_rate >= CAP_RATE_THRESHOLDS['excellent']['min']:
            self.recommendations.append({
                'type': 'success',
                'category': 'cap_rate',
                'message': get_text('cap_rate_excellent_recommendation').format(cap_rate=cap_rate)
            })
        elif cap_rate >= CAP_RATE_THRESHOLDS['needs_improvement']['min']:
            self.recommendations.append({
                'type': 'warning',
                'category': 'cap_rate',
                'message': get_text('cap_rate_moderate_recommendation').format(cap_rate=cap_rate)
            })
        else:
            self.recommendations.append({
                'type': 'error',
                'category': 'cap_rate',
                'message': get_text('cap_rate_poor_recommendation').format(cap_rate=cap_rate)
            })
        
        # Additional cap rate insights
        if 'individual_values' in cap_rate_result:
            individual_rates = cap_rate_result['individual_values']
            min_rate = min(individual_rates)
            max_rate = max(individual_rates)
            
            if max_rate - min_rate > 5:  # High variance
                self.recommendations.append({
                    'type': 'info',
                    'category': 'cap_rate',
                    'message': get_text('cap_rate_variance_warning').format(min_rate=min_rate, max_rate=max_rate)
                })
    
    def _analyze_noi(self, noi_result: Dict[str, Any]):
        """Analyze Net Operating Income"""
        
        noi = noi_result['value']
        
        if noi > 0:
            self.recommendations.append({
                'type': 'success',
                'category': 'noi',
                'message': get_text('noi_positive_recommendation').format(noi=noi)
            })
        elif noi == 0:
            self.recommendations.append({
                'type': 'warning',
                'category': 'noi',
                'message': get_text('noi_breakeven_recommendation')
            })
        else:
            self.recommendations.append({
                'type': 'error',
                'category': 'noi',
                'message': get_text('noi_negative_recommendation').format(noi=abs(noi))
            })
        
        # NOI improvement suggestions
        if noi < 10000:  # Low NOI threshold
            self.recommendations.append({
                'type': 'info',
                'category': 'noi',
                'message': get_text('noi_improvement_suggestion')
            })
    
    def _analyze_opportunity_cost(self, opportunity_cost_result: Dict[str, Any]):
        """Analyze opportunity cost"""
        
        opportunity_cost = opportunity_cost_result['value']
        
        if opportunity_cost < 0:  # Property performs better than 5% alternative
            self.recommendations.append({
                'type': 'success',
                'category': 'opportunity_cost',
                'message': get_text('opportunity_cost_favorable').format(cost=abs(opportunity_cost))
            })
        elif opportunity_cost == 0:
            self.recommendations.append({
                'type': 'info',
                'category': 'opportunity_cost',
                'message': get_text('opportunity_cost_neutral')
            })
        else:
            self.recommendations.append({
                'type': 'warning',
                'category': 'opportunity_cost',
                'message': get_text('opportunity_cost_unfavorable').format(cost=opportunity_cost)
            })
    
    def _analyze_property_age(self, age_result: Dict[str, Any]):
        """Analyze property age"""
        
        avg_age = age_result['value']
        
        if avg_age < 5:
            self.recommendations.append({
                'type': 'success',
                'category': 'property_age',
                'message': get_text('property_age_new').format(age=avg_age)
            })
        elif avg_age < 15:
            self.recommendations.append({
                'type': 'info',
                'category': 'property_age',
                'message': get_text('property_age_moderate').format(age=avg_age)
            })
        elif avg_age < 30:
            self.recommendations.append({
                'type': 'warning',
                'category': 'property_age',
                'message': get_text('property_age_older').format(age=avg_age)
            })
        else:
            self.recommendations.append({
                'type': 'error',
                'category': 'property_age',
                'message': get_text('property_age_very_old').format(age=avg_age)
            })
    
    def _analyze_growth_rate(self, growth_result: Dict[str, Any]):
        """Analyze annual growth rate"""
        
        growth_rate = growth_result['value']
        
        if growth_rate > 5:
            self.recommendations.append({
                'type': 'success',
                'category': 'growth_rate',
                'message': get_text('growth_rate_excellent').format(rate=growth_rate)
            })
        elif growth_rate > 2:
            self.recommendations.append({
                'type': 'info',
                'category': 'growth_rate',
                'message': get_text('growth_rate_good').format(rate=growth_rate)
            })
        elif growth_rate > 0:
            self.recommendations.append({
                'type': 'warning',
                'category': 'growth_rate',
                'message': get_text('growth_rate_low').format(rate=growth_rate)
            })
        else:
            self.recommendations.append({
                'type': 'error',
                'category': 'growth_rate',
                'message': get_text('growth_rate_negative').format(rate=growth_rate)
            })
    
    def _generate_combined_recommendations(self, results: Dict[str, Any], selected_kpis: List[str]):
        """Generate recommendations based on combined analysis"""
        
        # Overall investment grade
        positive_indicators = 0
        negative_indicators = 0
        
        # Count positive/negative indicators
        if 'cap_rate' in results and results['cap_rate']['status'] == 'success':
            if results['cap_rate']['value'] >= 8:
                positive_indicators += 2
            elif results['cap_rate']['value'] >= 5:
                positive_indicators += 1
            else:
                negative_indicators += 2
        
        if 'noi' in results and results['noi']['status'] == 'success':
            if results['noi']['value'] > 0:
                positive_indicators += 1
            else:
                negative_indicators += 1
        
        if 'opportunity_cost' in results and results['opportunity_cost']['status'] == 'success':
            if results['opportunity_cost']['value'] < 0:
                positive_indicators += 1
            else:
                negative_indicators += 1
        
        if 'annual_growth_rate' in results and results['annual_growth_rate']['status'] == 'success':
            if results['annual_growth_rate']['value'] > 3:
                positive_indicators += 1
            elif results['annual_growth_rate']['value'] < 0:
                negative_indicators += 1
        
        # Generate overall recommendation
        if positive_indicators >= negative_indicators + 2:
            self.recommendations.append({
                'type': 'success',
                'category': 'overall',
                'message': get_text('overall_recommendation_strong_buy')
            })
        elif positive_indicators > negative_indicators:
            self.recommendations.append({
                'type': 'info',
                'category': 'overall',
                'message': get_text('overall_recommendation_consider')
            })
        elif positive_indicators == negative_indicators:
            self.recommendations.append({
                'type': 'warning',
                'category': 'overall',
                'message': get_text('overall_recommendation_neutral')
            })
        else:
            self.recommendations.append({
                'type': 'error',
                'category': 'overall',
                'message': get_text('overall_recommendation_avoid')
            })
        
        # Risk assessment
        self._assess_investment_risk(results)
    
    def _assess_investment_risk(self, results: Dict[str, Any]):
        """Assess overall investment risk"""
        
        risk_factors = []
        
        # High property age risk
        if 'avg_property_age' in results and results['avg_property_age']['value'] > 25:
            risk_factors.append(get_text('risk_factor_old_property'))
        
        # Negative NOI risk
        if 'noi' in results and results['noi']['value'] < 0:
            risk_factors.append(get_text('risk_factor_negative_noi'))
        
        # Low cap rate risk
        if 'cap_rate' in results and results['cap_rate']['value'] < 3:
            risk_factors.append(get_text('risk_factor_low_cap_rate'))
        
        # Negative growth risk
        if 'annual_growth_rate' in results and results['annual_growth_rate']['value'] < 0:
            risk_factors.append(get_text('risk_factor_negative_growth'))
        
        if risk_factors:
            self.recommendations.append({
                'type': 'warning',
                'category': 'risk',
                'message': get_text('risk_assessment_warning') + ': ' + ', '.join(risk_factors)
            })
        else:
            self.recommendations.append({
                'type': 'success',
                'category': 'risk',
                'message': get_text('risk_assessment_low')
            })

def get_cap_rate_recommendation(cap_rate: float) -> tuple:
    """
    Analyzes the Cap Rate and returns a recommendation tuple (text, color_name).
    
    Args:
        cap_rate (float): The calculated capitalization rate.

    Returns:
        tuple: A tuple containing the recommendation text and the color name 
               (e.g., ("Excellent", "success"), ("Weak", "error")).
    """
    if cap_rate > 8:
        return ("Excellent", "success")  # "success" is the green color name in Streamlit
    elif cap_rate >= 5:
        return ("Needs Improvement", "warning") # "warning" is the yellow/orange color name
    else:
        return ("Weak", "error") # "error" is the red color name
