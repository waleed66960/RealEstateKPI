"""Core real estate analysis engine"""

import pandas as pd
import numpy as np
from typing import Dict, List, Any
from config.settings import AVAILABLE_KPIS

class RealEstateAnalyzer:
    """Main analyzer class for real estate financial metrics"""
    
    def __init__(self):
        self.results = {}
    
    def analyze(self, data: pd.DataFrame, selected_kpis: List[str]) -> Dict[str, Any]:
        """
        Perform analysis on the provided data for selected KPIs
        
        Args:
            data: DataFrame containing property data
            selected_kpis: List of KPI keys to calculate
            
        Returns:
            Dictionary containing analysis results
        """
        
        self.results = {}
        
        for kpi in selected_kpis:
            if kpi in AVAILABLE_KPIS:
                try:
                    result = self._calculate_kpi(data, kpi)
                    self.results[kpi] = result
                except Exception as e:
                    self.results[kpi] = {
                        'value': None,
                        'error': str(e),
                        'status': 'error'
                    }
        
        return self.results
    
    def _calculate_kpi(self, data: pd.DataFrame, kpi: str) -> Dict[str, Any]:
        """Calculate individual KPI"""
        
        kpi_info = AVAILABLE_KPIS[kpi]
        required_fields = kpi_info['required_fields']
        
        # Validate required fields exist
        missing_fields = [field for field in required_fields if field not in data.columns]
        if missing_fields:
            raise ValueError(f"Missing required fields: {missing_fields}")
        
        # Calculate based on KPI type
        if kpi == 'noi':
            return self._calculate_noi(data)
        elif kpi == 'cap_rate':
            return self._calculate_cap_rate(data)
        elif kpi == 'opportunity_cost':
            return self._calculate_opportunity_cost(data)
        elif kpi == 'avg_property_age':
            return self._calculate_avg_property_age(data)
        elif kpi == 'annual_growth_rate':
            return self._calculate_annual_growth_rate(data)
        else:
            raise ValueError(f"Unknown KPI: {kpi}")
    
    def _calculate_noi(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Calculate Net Operating Income"""
        
        noi_values = data['TotalIncome'] - data['Expenses']
        avg_noi = noi_values.mean()
        
        return {
            'value': avg_noi,
            'individual_values': noi_values.tolist(),
            'min': noi_values.min(),
            'max': noi_values.max(),
            'status': 'success',
            'unit': 'USD'
        }
    
    def _calculate_cap_rate(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Calculate Capitalization Rate"""
        
        # First calculate NOI for each property
        noi_values = data['TotalIncome'] - data['Expenses']
        
        # Calculate cap rate for each property
        cap_rate_values = (noi_values / data['PropertyValue']) * 100
        
        # Remove infinite and NaN values
        cap_rate_values = cap_rate_values.replace([np.inf, -np.inf], np.nan).dropna()
        
        if cap_rate_values.empty:
            raise ValueError("Unable to calculate cap rate - all values are invalid")
        
        avg_cap_rate = cap_rate_values.mean()
        
        return {
            'value': avg_cap_rate,
            'individual_values': cap_rate_values.tolist(),
            'min': cap_rate_values.min(),
            'max': cap_rate_values.max(),
            'status': 'success',
            'unit': 'percentage'
        }
    
    def _calculate_opportunity_cost(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Calculate Opportunity Cost (assuming 5% alternative investment)"""
        
        # Calculate NOI first
        noi_values = data['TotalIncome'] - data['Expenses']
        
        # Calculate opportunity cost
        alternative_return = data['PropertyValue'] * 0.05
        opportunity_cost_values = alternative_return - noi_values
        
        avg_opportunity_cost = opportunity_cost_values.mean()
        
        return {
            'value': avg_opportunity_cost,
            'individual_values': opportunity_cost_values.tolist(),
            'min': opportunity_cost_values.min(),
            'max': opportunity_cost_values.max(),
            'status': 'success',
            'unit': 'USD'
        }
    
    def _calculate_avg_property_age(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Calculate Average Property Age"""
        
        avg_age = data['PropertyAge'].mean()
        
        return {
            'value': avg_age,
            'individual_values': data['PropertyAge'].tolist(),
            'min': data['PropertyAge'].min(),
            'max': data['PropertyAge'].max(),
            'status': 'success',
            'unit': 'years'
        }
    
    def _calculate_annual_growth_rate(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Calculate Annual Growth Rate"""
        
        avg_growth = data['AnnualGrowthRate'].mean()
        
        return {
            'value': avg_growth,
            'individual_values': data['AnnualGrowthRate'].tolist(),
            'min': data['AnnualGrowthRate'].min(),
            'max': data['AnnualGrowthRate'].max(),
            'status': 'success',
            'unit': 'percentage'
        }
    
    def get_portfolio_summary(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Generate portfolio summary statistics"""
        
        if data.empty:
            return {}
        
        summary = {
            'total_properties': len(data),
            'total_income': data['TotalIncome'].sum() if 'TotalIncome' in data.columns else 0,
            'total_expenses': data['Expenses'].sum() if 'Expenses' in data.columns else 0,
            'total_value': data['PropertyValue'].sum() if 'PropertyValue' in data.columns else 0,
            'avg_property_age': data['PropertyAge'].mean() if 'PropertyAge' in data.columns else 0,
            'avg_growth_rate': data['AnnualGrowthRate'].mean() if 'AnnualGrowthRate' in data.columns else 0
        }
        
        # Calculate portfolio NOI and Cap Rate
        if all(col in data.columns for col in ['TotalIncome', 'Expenses', 'PropertyValue']):
            portfolio_noi = summary['total_income'] - summary['total_expenses']
            portfolio_cap_rate = (portfolio_noi / summary['total_value']) * 100 if summary['total_value'] > 0 else 0
            
            summary['portfolio_noi'] = portfolio_noi
            summary['portfolio_cap_rate'] = portfolio_cap_rate
        
        return summary
