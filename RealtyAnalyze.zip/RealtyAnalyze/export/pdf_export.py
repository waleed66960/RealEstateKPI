"""PDF export functionality for analysis reports"""

import streamlit as st
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.colors import black, blue, green, orange, red
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
import io
from datetime import datetime
from typing import Dict, List, Any
from utils.localization import get_text, is_rtl
from config.settings import AVAILABLE_KPIS

class PDFReportGenerator:
    """Generate PDF reports for real estate analysis"""
    
    def __init__(self):
        self.buffer = io.BytesIO()
        self.styles = getSampleStyleSheet()
        self.setup_custom_styles()
    
    def setup_custom_styles(self):
        """Setup custom paragraph styles"""
        
        # Title style
        self.styles.add(ParagraphStyle(
            name='CustomTitle',
            parent=self.styles['Title'],
            fontSize=24,
            textColor=blue,
            alignment=TA_CENTER,
            spaceAfter=30
        ))
        
        # Subtitle style
        self.styles.add(ParagraphStyle(
            name='CustomSubtitle',
            parent=self.styles['Heading2'],
            fontSize=16,
            textColor=black,
            alignment=TA_LEFT,
            spaceAfter=20
        ))
        
        # KPI Value style
        self.styles.add(ParagraphStyle(
            name='KPIValue',
            parent=self.styles['Normal'],
            fontSize=14,
            textColor=blue,
            alignment=TA_CENTER,
            spaceAfter=10
        ))
        
        # Recommendation styles
        self.styles.add(ParagraphStyle(
            name='RecommendationSuccess',
            parent=self.styles['Normal'],
            fontSize=12,
            textColor=green,
            alignment=TA_LEFT,
            spaceAfter=10
        ))
        
        self.styles.add(ParagraphStyle(
            name='RecommendationWarning',
            parent=self.styles['Normal'],
            fontSize=12,
            textColor=orange,
            alignment=TA_LEFT,
            spaceAfter=10
        ))
        
        self.styles.add(ParagraphStyle(
            name='RecommendationError',
            parent=self.styles['Normal'],
            fontSize=12,
            textColor=red,
            alignment=TA_LEFT,
            spaceAfter=10
        ))
    
    def generate_report(self, results: Dict[str, Any], selected_kpis: List[str]) -> bytes:
        """Generate complete PDF report"""
        
        # Create PDF document
        doc = SimpleDocTemplate(
            self.buffer,
            pagesize=A4,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=18
        )
        
        # Build content
        story = []
        
        # Add header
        story.extend(self.create_header())
        
        # Add KPI results
        story.extend(self.create_kpi_section(results, selected_kpis))
        
        # Add recommendations
        story.extend(self.create_recommendations_section(results, selected_kpis))
        
        # Add footer info
        story.extend(self.create_footer())
        
        # Build PDF
        doc.build(story)
        
        # Get PDF data
        pdf_data = self.buffer.getvalue()
        self.buffer.close()
        
        return pdf_data
    
    def create_header(self) -> List:
        """Create report header"""
        
        elements = []
        
        # Title
        title = Paragraph(get_text("app_title"), self.styles['CustomTitle'])
        elements.append(title)
        elements.append(Spacer(1, 20))
        
        # Report info
        report_date = datetime.now().strftime("%Y-%m-%d %H:%M")
        date_text = f"{get_text('report_generated_on', date=report_date)}"
        
        elements.append(Paragraph(date_text, self.styles['Normal']))
        elements.append(Spacer(1, 30))
        
        return elements
    
    def create_kpi_section(self, results: Dict[str, Any], selected_kpis: List[str]) -> List:
        """Create KPI results section"""
        
        elements = []
        
        # Section title
        title = Paragraph(get_text("key_metrics"), self.styles['CustomSubtitle'])
        elements.append(title)
        elements.append(Spacer(1, 20))
        
        # Create table data
        table_data = []
        
        # Header row
        lang = st.session_state.get('language', 'en')
        table_data.append([
            get_text("kpi_name"),
            get_text("value"),
            get_text("unit"),
            get_text("status")
        ])
        
        # Add KPI rows
        for kpi in selected_kpis:
            if kpi in results and results[kpi]['status'] == 'success':
                kpi_info = AVAILABLE_KPIS[kpi]
                kpi_name = kpi_info[f'name_{lang}']
                value = results[kpi]['value']
                unit = results[kpi].get('unit', '')
                
                # Format value based on type
                if unit == 'percentage':
                    formatted_value = f"{value:.2f}%"
                elif unit == 'USD':
                    formatted_value = f"${value:,.2f}"
                elif unit == 'years':
                    formatted_value = f"{value:.1f} years"
                else:
                    formatted_value = f"{value:.2f}"
                
                status = "✓ " + get_text("success")
                
                table_data.append([
                    kpi_name,
                    formatted_value,
                    self.get_unit_display(unit),
                    status
                ])
        
        # Create table
        if len(table_data) > 1:
            table = Table(table_data)
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), blue),
                ('TEXTCOLOR', (0, 0), (-1, 0), black),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), '#f0f0f0'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 10),
                ('GRID', (0, 0), (-1, -1), 1, black)
            ]))
            
            elements.append(table)
            elements.append(Spacer(1, 30))
        
        return elements
    
    def create_recommendations_section(self, results: Dict[str, Any], selected_kpis: List[str]) -> List:
        """Create recommendations section"""
        
        elements = []
        
        # Section title
        title = Paragraph(get_text("investment_recommendations"), self.styles['CustomSubtitle'])
        elements.append(title)
        elements.append(Spacer(1, 20))
        
        # Generate recommendations
        from core.recommender import InvestmentRecommender
        recommender = InvestmentRecommender()
        recommendations = recommender.generate_recommendations(results, selected_kpis)
        
        # Add recommendations
        for rec in recommendations:
            if rec['type'] == 'success':
                style = 'RecommendationSuccess'
                icon = "✅ "
            elif rec['type'] == 'warning':
                style = 'RecommendationWarning'
                icon = "⚠️ "
            elif rec['type'] == 'error':
                style = 'RecommendationError'
                icon = "❌ "
            else:
                style = 'Normal'
                icon = "💡 "
            
            text = f"{icon}{rec['message']}"
            elements.append(Paragraph(text, self.styles[style]))
        
        elements.append(Spacer(1, 30))
        
        return elements
    
    def create_footer(self) -> List:
        """Create report footer"""
        
        elements = []
        
        # Add disclaimer
        disclaimer_title = Paragraph(get_text("disclaimer"), self.styles['Heading3'])
        elements.append(disclaimer_title)
        
        disclaimer_text = get_text("report_disclaimer")
        elements.append(Paragraph(disclaimer_text, self.styles['Normal']))
        elements.append(Spacer(1, 20))
        
        # Add contact info
        contact_info = get_text("contact_info")
        elements.append(Paragraph(contact_info, self.styles['Normal']))
        
        return elements
    
    def get_unit_display(self, unit: str) -> str:
        """Get display text for unit"""
        
        unit_displays = {
            'USD': get_text("dollars"),
            'percentage': get_text("percent"),
            'years': get_text("years"),
            '': ''
        }
        
        return unit_displays.get(unit, unit)

def generate_pdf_report(results: Dict[str, Any], selected_kpis: List[str]) -> bytes:
    """Generate PDF report - main function"""
    
    try:
        generator = PDFReportGenerator()
        return generator.generate_report(results, selected_kpis)
    
    except Exception as e:
        # Fallback: Generate simple text-based PDF
        return generate_simple_pdf_report(results, selected_kpis, str(e))

def generate_simple_pdf_report(results: Dict[str, Any], selected_kpis: List[str], error_msg: str = None) -> bytes:
    """Generate simple PDF report as fallback"""
    
    buffer = io.BytesIO()
    
    # Create simple PDF with basic text
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import letter
    
    c = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    
    # Title
    c.setFont("Helvetica-Bold", 20)
    c.drawString(50, height - 50, get_text("app_title"))
    
    # Date
    c.setFont("Helvetica", 12)
    report_date = datetime.now().strftime("%Y-%m-%d %H:%M")
    c.drawString(50, height - 80, f"Report Date: {report_date}")
    
    # KPI Results
    y_position = height - 120
    c.setFont("Helvetica-Bold", 16)
    c.drawString(50, y_position, get_text("key_metrics"))
    
    y_position -= 30
    c.setFont("Helvetica", 12)
    
    for kpi in selected_kpis:
        if kpi in results and results[kpi]['status'] == 'success':
            lang = st.session_state.get('language', 'en')
            kpi_info = AVAILABLE_KPIS[kpi]
            kpi_name = kpi_info[f'name_{lang}']
            value = results[kpi]['value']
            
            # Format value
            if results[kpi].get('unit') == 'percentage':
                formatted_value = f"{value:.2f}%"
            elif results[kpi].get('unit') == 'USD':
                formatted_value = f"${value:,.2f}"
            else:
                formatted_value = f"{value:.2f}"
            
            text = f"{kpi_name}: {formatted_value}"
            c.drawString(70, y_position, text)
            y_position -= 20
            
            if y_position < 100:  # Start new page if needed
                c.showPage()
                y_position = height - 50
    
    # Error message if any
    if error_msg:
        y_position -= 30
        c.setFont("Helvetica", 10)
        c.drawString(50, y_position, f"Note: Advanced formatting unavailable - {error_msg}")
    
    c.save()
    
    pdf_data = buffer.getvalue()
    buffer.close()
    
    return pdf_data

def create_chart_image(results: Dict[str, Any], selected_kpis: List[str]) -> bytes:
    """Create chart image for PDF (optional enhancement)"""
    
    try:
        import matplotlib.pyplot as plt
        import matplotlib
        matplotlib.use('Agg')  # Use non-interactive backend
        
        # Create simple bar chart
        kpi_names = []
        kpi_values = []
        
        lang = st.session_state.get('language', 'en')
        
        for kpi in selected_kpis:
            if kpi in results and results[kpi]['status'] == 'success':
                kpi_info = AVAILABLE_KPIS[kpi]
                kpi_names.append(kpi_info[f'name_{lang}'])
                kpi_values.append(results[kpi]['value'])
        
        if kpi_names and kpi_values:
            plt.figure(figsize=(10, 6))
            plt.bar(kpi_names, kpi_values)
            plt.title(get_text("kpi_comparison"))
            plt.xticks(rotation=45, ha='right')
            plt.tight_layout()
            
            # Save to buffer
            img_buffer = io.BytesIO()
            plt.savefig(img_buffer, format='png', dpi=300, bbox_inches='tight')
            img_buffer.seek(0)
            
            plt.close()
            
            return img_buffer.getvalue()
    
    except ImportError:
        # matplotlib not available
        pass
    except Exception as e:
        print(f"Error creating chart: {e}")
    
    return None

