"""Analysis results display component"""

import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from utils.localization import get_text
from config.settings import CAP_RATE_THRESHOLDS
from core.recommender import InvestmentRecommender, get_cap_rate_recommendation
from export.pdf_export import generate_pdf_report

def analysis_display_component(results, selected_kpis):
    """Component for displaying analysis results"""
    
    st.subheader(get_text("analysis_results"))
    
    # Display KPI metrics
    display_kpi_metrics(results, selected_kpis)
    
    # Display charts
    display_charts(results, selected_kpis)
    
    # Display recommendations
    display_recommendations(results, selected_kpis)
    
    # Export options
    display_export_options(results, selected_kpis)

def display_kpi_metrics(results, selected_kpis):
    """Display KPI metrics in cards"""
    
    st.subheader(get_text("key_metrics"))
    
    # Create columns for metrics
    cols = st.columns(min(len(selected_kpis), 3))
    
    for idx, kpi in enumerate(selected_kpis):
        col = cols[idx % len(cols)]
        
        with col:
            if kpi in results:
                value = results[kpi]['value']
                
                # Format value based on KPI type
                if kpi == 'cap_rate':
                    formatted_value = f"{value:.2f}%"
                    delta_color = get_cap_rate_color(value)
                elif kpi in ['noi', 'opportunity_cost']:
                    formatted_value = f"${value:,.2f}"
                    delta_color = "normal"
                elif kpi == 'avg_property_age':
                    formatted_value = f"{value:.1f} years"
                    delta_color = "normal"
                elif kpi == 'annual_growth_rate':
                    formatted_value = f"{value:.2f}%"
                    delta_color = "normal"
                else:
                    formatted_value = f"{value:.2f}"
                    delta_color = "normal"
                
                # Get KPI name in current language
                lang = st.session_state.language
                from config.settings import AVAILABLE_KPIS
                kpi_name = AVAILABLE_KPIS[kpi][f'name_{lang}']
                
                st.metric(
                    label=kpi_name,
                    value=formatted_value,
                    help=get_kpi_help_text(kpi)
                )
                
                # Add colored indicator for cap rate
                if kpi == 'cap_rate':
                    recommendation = get_cap_rate_recommendation(value)
                    st.markdown(f"<div style='text-align: center; color: {recommendation['color']}'>"
                              f"{recommendation['emoji']} {get_text(recommendation['text_key'])}</div>", 
                              unsafe_allow_html=True)

def display_charts(results, selected_kpis):
    """Display visualization charts"""
    
    if len(selected_kpis) <= 1:
        return
    
    st.subheader(get_text("visualizations"))
    
    # Prepare data for charts
    chart_data = []
    for kpi in selected_kpis:
        if kpi in results:
            lang = st.session_state.language
            from config.settings import AVAILABLE_KPIS
            kpi_name = AVAILABLE_KPIS[kpi][f'name_{lang}']
            
            chart_data.append({
                'KPI': kpi_name,
                'Value': results[kpi]['value'],
                'Key': kpi
            })
    
    if not chart_data:
        return
    
    # Create different chart types based on KPIs
    col1, col2 = st.columns(2)
    
    with col1:
        # Bar chart for all metrics
        fig_bar = px.bar(
            chart_data,
            x='KPI',
            y='Value',
            title=get_text("kpi_comparison"),
            color='Value',
            color_continuous_scale='viridis'
        )
        fig_bar.update_layout(
            xaxis_title=get_text("metrics"),
            yaxis_title=get_text("values"),
            showlegend=False
        )
        st.plotly_chart(fig_bar, use_container_width=True)
    
    with col2:
        # Pie chart for percentage metrics
        percentage_kpis = [item for item in chart_data if item['Key'] in ['cap_rate', 'annual_growth_rate']]
        
        if percentage_kpis:
            fig_pie = px.pie(
                percentage_kpis,
                values='Value',
                names='KPI',
                title=get_text("percentage_metrics")
            )
            st.plotly_chart(fig_pie, use_container_width=True)
        else:
            # Alternative: Show a gauge chart for cap rate if available
            if 'cap_rate' in [item['Key'] for item in chart_data]:
                cap_rate_value = next(item['Value'] for item in chart_data if item['Key'] == 'cap_rate')
                
                fig_gauge = go.Figure(go.Indicator(
                    mode = "gauge+number+delta",
                    value = cap_rate_value,
                    domain = {'x': [0, 1], 'y': [0, 1]},
                    title = {'text': get_text("cap_rate_gauge")},
                    delta = {'reference': 6},
                    gauge = {
                        'axis': {'range': [None, 15]},
                        'bar': {'color': "darkblue"},
                        'steps': [
                            {'range': [0, 5], 'color': "lightgray"},
                            {'range': [5, 8], 'color': "yellow"},
                            {'range': [8, 15], 'color': "green"}
                        ],
                        'threshold': {
                            'line': {'color': "red", 'width': 4},
                            'thickness': 0.75,
                            'value': 8
                        }
                    }
                ))
                st.plotly_chart(fig_gauge, use_container_width=True)

def display_recommendations(results, selected_kpis):
    """Display investment recommendations"""
    
    st.subheader(get_text("investment_recommendations"))
    
    recommender = InvestmentRecommender()
    recommendations = recommender.generate_recommendations(results, selected_kpis)
    
    for recommendation in recommendations:
        if recommendation['type'] == 'success':
            st.success(f"✅ {recommendation['message']}")
        elif recommendation['type'] == 'warning':
            st.warning(f"⚠️ {recommendation['message']}")
        elif recommendation['type'] == 'error':
            st.error(f"❌ {recommendation['message']}")
        else:
            st.info(f"💡 {recommendation['message']}")

def display_export_options(results, selected_kpis):
    """Display export options"""
    
    st.subheader(get_text("export_options"))
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button(get_text("export_pdf")):
            try:
                pdf_data = generate_pdf_report(results, selected_kpis)
                st.download_button(
                    label=get_text("download_pdf_report"),
                    data=pdf_data,
                    file_name="real_estate_analysis_report.pdf",
                    mime="application/pdf"
                )
                st.success(get_text("pdf_generated"))
            except Exception as e:
                st.error(f"{get_text('pdf_generation_error')}: {str(e)}")
    
    with col2:
        if st.button(get_text("export_json")):
            import json
            json_data = json.dumps(results, indent=2, ensure_ascii=False)
            st.download_button(
                label=get_text("download_json_data"),
                data=json_data,
                file_name="analysis_results.json",
                mime="application/json"
            )
            st.success(get_text("json_exported"))

def get_cap_rate_color(cap_rate):
    """Get color for cap rate based on thresholds"""
    if cap_rate >= CAP_RATE_THRESHOLDS['excellent']['min']:
        return 'green'
    elif cap_rate >= CAP_RATE_THRESHOLDS['needs_improvement']['min']:
        return 'orange'
    else:
        return 'red'

def get_cap_rate_recommendation(cap_rate):
    """Get recommendation for cap rate"""
    if cap_rate >= CAP_RATE_THRESHOLDS['excellent']['min']:
        return {
            'color': CAP_RATE_THRESHOLDS['excellent']['color'],
            'emoji': CAP_RATE_THRESHOLDS['excellent']['emoji'],
            'text_key': 'excellent_investment'
        }
    elif cap_rate >= CAP_RATE_THRESHOLDS['needs_improvement']['min']:
        return {
            'color': CAP_RATE_THRESHOLDS['needs_improvement']['color'],
            'emoji': CAP_RATE_THRESHOLDS['needs_improvement']['emoji'],
            'text_key': 'needs_improvement'
        }
    else:
        return {
            'color': CAP_RATE_THRESHOLDS['weak']['color'],
            'emoji': CAP_RATE_THRESHOLDS['weak']['emoji'],
            'text_key': 'weak_investment'
        }

def get_kpi_help_text(kpi):
    """Get help text for KPI"""
    help_texts = {
        'noi': {
            'en': 'Higher NOI indicates better cash flow',
            'ar': 'صافي دخل أعلى يعني تدفق نقدي أفضل'
        },
        'cap_rate': {
            'en': 'Higher cap rate indicates better returns',
            'ar': 'معدل رسملة أعلى يعني عوائد أفضل'
        },
        'opportunity_cost': {
            'en': 'Lower opportunity cost is better',
            'ar': 'تكلفة فرصة أقل هي الأفضل'
        },
        'avg_property_age': {
            'en': 'Consider maintenance needs for older properties',
            'ar': 'اعتبر احتياجات الصيانة للعقارات الأقدم'
        },
        'annual_growth_rate': {
            'en': 'Higher growth rate indicates better appreciation potential',
            'ar': 'معدل نمو أعلى يعني إمكانية تقدير أفضل'
        }
    }
    
    lang = st.session_state.language
    return help_texts.get(kpi, {}).get(lang, '')
