"""KPI metric selector component"""

import streamlit as st
from utils.localization import get_text
from config.settings import AVAILABLE_KPIS

def metric_selector_component():
    """Component for selecting KPIs to analyze"""
    
    st.subheader(get_text("metric_selector_title"))
    st.write(get_text("metric_selector_description"))
    
    # Create KPI options based on language
    kpi_options = {}
    lang = st.session_state.language
    
    for kpi_key, kpi_info in AVAILABLE_KPIS.items():
        if lang == 'ar':
            display_name = kpi_info['name_ar']
        else:
            display_name = kpi_info['name_en']
        
        kpi_options[display_name] = kpi_key
    
    # Multi-select for KPIs
    selected_kpi_names = st.multiselect(
        get_text("select_kpis"),
        options=list(kpi_options.keys()),
        help=get_text("select_kpis_help")
    )
    
    # Convert back to KPI keys
    selected_kpis = [kpi_options[name] for name in selected_kpi_names]
    
    # Store in session state
    st.session_state.selected_kpis = selected_kpis
    
    if selected_kpis:
        # Display selected KPIs and their required fields
        st.subheader(get_text("selected_kpis_summary"))
        
        for kpi in selected_kpis:
            kpi_info = AVAILABLE_KPIS[kpi]
            
            with st.expander(f"📊 {kpi_info[f'name_{lang}']}"):
                st.write(f"**{get_text('formula')}:** {kpi_info['formula']}")
                st.write(f"**{get_text('required_fields')}:** {', '.join(kpi_info['required_fields'])}")
        
        # Show all required fields for selected KPIs
        all_required_fields = set()
        for kpi in selected_kpis:
            all_required_fields.update(AVAILABLE_KPIS[kpi]['required_fields'])
        
        st.info(f"{get_text('total_required_fields')}: {', '.join(sorted(all_required_fields))}")
    
    else:
        st.warning(get_text("no_kpis_selected_warning"))
    
    return selected_kpis

def display_kpi_descriptions():
    """Display detailed descriptions of all available KPIs"""
    
    st.subheader(get_text("available_kpis"))
    
    lang = st.session_state.language
    
    for kpi_key, kpi_info in AVAILABLE_KPIS.items():
        with st.expander(f"📈 {kpi_info[f'name_{lang}']}"):
            st.markdown(f"**{get_text('formula')}:** `{kpi_info['formula']}`")
            st.markdown(f"**{get_text('required_fields')}:** {', '.join(kpi_info['required_fields'])}")
            
            # Add specific descriptions for each KPI
            descriptions = {
                'noi': {
                    'en': 'Net Operating Income represents the property\'s annual income after operating expenses.',
                    'ar': 'صافي الدخل التشغيلي يمثل الدخل السنوي للعقار بعد خصم مصاريف التشغيل.'
                },
                'cap_rate': {
                    'en': 'Capitalization Rate measures the rate of return on a real estate investment.',
                    'ar': 'معدل الرسملة يقيس معدل العائد على الاستثمار العقاري.'
                },
                'opportunity_cost': {
                    'en': 'Opportunity Cost compares the property investment to a 5% alternative investment.',
                    'ar': 'تكلفة الفرصة البديلة تقارن الاستثمار العقاري ببديل بعائد 5%.'
                },
                'avg_property_age': {
                    'en': 'Average Property Age helps assess the condition and maintenance needs.',
                    'ar': 'متوسط عمر العقار يساعد في تقييم الحالة واحتياجات الصيانة.'
                },
                'annual_growth_rate': {
                    'en': 'Annual Growth Rate indicates the expected appreciation in property value.',
                    'ar': 'معدل النمو السنوي يشير إلى الزيادة المتوقعة في قيمة العقار.'
                }
            }
            
            if kpi_key in descriptions:
                st.markdown(descriptions[kpi_key][lang])
