"""Enhanced file validation with detailed feedback"""

import streamlit as st
import pandas as pd
from utils.localization import get_text
from config.settings import AVAILABLE_KPIS

def enhanced_file_validation_component(uploaded_file, df: pd.DataFrame):
    """Enhanced file validation with detailed feedback and suggestions"""
    
    if uploaded_file is None or df is None:
        return
    
    st.subheader(get_text("file_validation_results"))
    
    # Get file info
    file_info = {
        'name': uploaded_file.name,
        'size': uploaded_file.size,
        'rows': len(df),
        'columns': len(df.columns)
    }
    
    # Display file summary
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(get_text("file_name"), file_info['name'])
    
    with col2:
        st.metric(get_text("file_size"), f"{file_info['size'] / 1024:.1f} KB")
    
    with col3:
        st.metric(get_text("total_rows"), file_info['rows'])
    
    with col4:
        st.metric(get_text("total_columns"), file_info['columns'])
    
    # Column analysis
    st.subheader(get_text("column_analysis"))
    
    # Check which KPIs can be calculated
    available_columns = set(df.columns)
    calculable_kpis = []
    missing_requirements = {}
    
    for kpi, kpi_info in AVAILABLE_KPIS.items():
        required_fields = set(kpi_info['required_fields'])
        
        if required_fields.issubset(available_columns):
            calculable_kpis.append(kpi)
        else:
            missing_fields = required_fields - available_columns
            missing_requirements[kpi] = missing_fields
    
    # Display calculable KPIs
    if calculable_kpis:
        st.success(f"✅ {get_text('can_calculate_kpis')}: {len(calculable_kpis)}")
        
        with st.expander(get_text("available_kpis_detail")):
            for kpi in calculable_kpis:
                lang = st.session_state.get('language', 'en')
                kpi_name = AVAILABLE_KPIS[kpi][f'name_{lang}']
                st.write(f"• {kpi_name}")
    
    # Display missing requirements
    if missing_requirements:
        st.warning(f"⚠️ {get_text('missing_requirements_for_kpis')}: {len(missing_requirements)}")
        
        with st.expander(get_text("missing_requirements_detail")):
            for kpi, missing_fields in missing_requirements.items():
                lang = st.session_state.get('language', 'en')
                kpi_name = AVAILABLE_KPIS[kpi][f'name_{lang}']
                st.write(f"• **{kpi_name}**: {get_text('missing_fields')} {', '.join(missing_fields)}")
    
    # Column mapping suggestions
    st.subheader(get_text("column_mapping_suggestions"))
    
    # Suggest possible mappings for missing columns
    all_required_fields = set()
    for kpi_info in AVAILABLE_KPIS.values():
        all_required_fields.update(kpi_info['required_fields'])
    
    suggestions = suggest_column_mappings(df.columns, all_required_fields)
    
    if suggestions:
        st.info(get_text("column_mapping_suggestions_found"))
        
        mapping_applied = False
        for target_field, suggested_columns in suggestions.items():
            if target_field not in available_columns:
                st.write(f"**{target_field}** {get_text('might_be')}:")
                
                for suggested_col in suggested_columns[:3]:  # Show top 3 suggestions
                    col1, col2 = st.columns([3, 1])
                    
                    with col1:
                        st.write(f"• {suggested_col}")
                    
                    with col2:
                        if st.button(get_text("use_this"), key=f"map_{target_field}_{suggested_col}"):
                            # Apply mapping
                            df.rename(columns={suggested_col: target_field}, inplace=True)
                            st.success(f"{get_text('mapped')} '{suggested_col}' → '{target_field}'")
                            mapping_applied = True
        
        if mapping_applied:
            st.rerun()
    
    # Data quality analysis
    st.subheader(get_text("data_quality_analysis"))
    
    quality_issues = analyze_data_quality(df)
    
    if quality_issues['errors']:
        st.error(f"❌ {get_text('data_errors_found')}: {len(quality_issues['errors'])}")
        for error in quality_issues['errors']:
            st.error(f"• {error}")
    
    if quality_issues['warnings']:
        st.warning(f"⚠️ {get_text('data_warnings_found')}: {len(quality_issues['warnings'])}")
        for warning in quality_issues['warnings']:
            st.warning(f"• {warning}")
    
    if not quality_issues['errors'] and not quality_issues['warnings']:
        st.success(f"✅ {get_text('data_quality_good')}")
    
    # Sample data preview with highlighting
    st.subheader(get_text("data_preview_with_analysis"))
    
    # Highlight columns based on their status
    def highlight_columns(s):
        if s.name in available_columns and any(s.name in AVAILABLE_KPIS[kpi]['required_fields'] for kpi in AVAILABLE_KPIS):
            return ['background-color: lightgreen'] * len(s)
        elif any(s.name.lower() in req_field.lower() for req_field in all_required_fields):
            return ['background-color: lightyellow'] * len(s)
        else:
            return ['background-color: lightgray'] * len(s)
    
    # Display styled dataframe
    styled_df = df.head(10).style.apply(highlight_columns, axis=0)
    st.dataframe(styled_df, use_container_width=True)
    
    # Legend
    st.markdown("""
    **Legend:**
    - 🟢 Green: Required columns for KPIs (ready to use)
    - 🟡 Yellow: Potential matches for required columns
    - ⚪ Gray: Other columns
    """)

def suggest_column_mappings(df_columns, required_fields):
    """Suggest column mappings based on similarity"""
    
    suggestions = {}
    
    # Convert to lowercase for comparison
    df_columns_lower = [col.lower().strip() for col in df_columns]
    
    for required_field in required_fields:
        required_lower = required_field.lower()
        matches = []
        
        # Exact matches
        for i, col in enumerate(df_columns_lower):
            if required_lower == col:
                matches.append(df_columns[i])
        
        # Partial matches
        if not matches:
            for i, col in enumerate(df_columns_lower):
                # Check if required field words are in column name
                required_words = required_lower.replace('_', ' ').split()
                col_words = col.replace('_', ' ').replace('-', ' ').split()
                
                # Calculate similarity score
                common_words = set(required_words) & set(col_words)
                if common_words:
                    score = len(common_words) / len(required_words)
                    if score >= 0.5:  # At least 50% word match
                        matches.append((df_columns[i], score))
        
        # Sort by score if we have scored matches
        if matches and isinstance(matches[0], tuple):
            matches.sort(key=lambda x: x[1], reverse=True)
            matches = [match[0] for match in matches]
        
        if matches:
            suggestions[required_field] = matches[:3]  # Top 3 suggestions
    
    return suggestions

def analyze_data_quality(df: pd.DataFrame):
    """Analyze data quality and return issues"""
    
    errors = []
    warnings = []
    
    # Check for completely empty columns
    for col in df.columns:
        if df[col].isna().all():
            errors.append(f"{get_text('column_completely_empty')}: {col}")
        elif df[col].isna().sum() / len(df) > 0.5:
            warnings.append(f"{get_text('column_mostly_empty')}: {col} ({df[col].isna().sum() / len(df) * 100:.1f}%)")
    
    # Check for numeric columns with text data
    numeric_columns = ['TotalIncome', 'Expenses', 'PropertyValue', 'PropertyAge', 'AnnualGrowthRate']
    
    for col in numeric_columns:
        if col in df.columns:
            non_numeric_count = 0
            for value in df[col].dropna():
                try:
                    float(str(value).replace(',', '').replace('$', '').replace('%', ''))
                except (ValueError, TypeError):
                    non_numeric_count += 1
            
            if non_numeric_count > 0:
                if non_numeric_count / len(df[col].dropna()) > 0.1:  # More than 10%
                    errors.append(f"{get_text('column_has_non_numeric')}: {col} ({non_numeric_count} values)")
                else:
                    warnings.append(f"{get_text('column_has_few_non_numeric')}: {col} ({non_numeric_count} values)")
    
    # Check for unrealistic values
    if 'PropertyValue' in df.columns:
        very_low = (df['PropertyValue'] < 1000).sum()
        very_high = (df['PropertyValue'] > 100000000).sum()
        
        if very_low > 0:
            warnings.append(f"{get_text('property_values_very_low')}: {very_low} properties")
        
        if very_high > 0:
            warnings.append(f"{get_text('property_values_very_high')}: {very_high} properties")
    
    if 'PropertyAge' in df.columns:
        negative_age = (df['PropertyAge'] < 0).sum()
        very_old = (df['PropertyAge'] > 200).sum()
        
        if negative_age > 0:
            errors.append(f"{get_text('negative_property_age')}: {negative_age} properties")
        
        if very_old > 0:
            warnings.append(f"{get_text('very_old_properties')}: {very_old} properties")
    
    return {'errors': errors, 'warnings': warnings}