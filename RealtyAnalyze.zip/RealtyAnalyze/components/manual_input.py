"""Manual data input component"""

import streamlit as st
import pandas as pd
from utils.localization import get_text
from config.settings import AVAILABLE_KPIS
from core.validator import DataValidator

def manual_input_component(selected_kpis):
    """Component for manual data entry"""
    
    st.subheader(get_text("manual_input_title"))
    
    # Determine required fields based on selected KPIs
    required_fields = set()
    for kpi in selected_kpis:
        if kpi in AVAILABLE_KPIS:
            required_fields.update(AVAILABLE_KPIS[kpi]['required_fields'])
    
    # Display required fields info
    st.info(f"{get_text('required_fields_info')}: {', '.join(required_fields)}")
    
    # Number of properties input
    num_properties = st.number_input(
        get_text("number_of_properties"),
        min_value=1,
        max_value=100,
        value=1,
        help=get_text("number_of_properties_help")
    )
    
    # Create input form
    with st.form("manual_data_form"):
        st.subheader(get_text("property_data_form"))
        
        # Initialize data storage
        data = {}
        for field in required_fields:
            data[field] = []
        
        # Create input fields for each property
        for i in range(num_properties):
            st.subheader(f"{get_text('property')} {i + 1}")
            
            cols = st.columns(2)
            
            for idx, field in enumerate(required_fields):
                col = cols[idx % 2]
                
                with col:
                    field_label = get_field_label(field)
                    field_help = get_field_help(field)
                    
                    if field in ['TotalIncome', 'Expenses', 'PropertyValue']:
                        value = st.number_input(
                            field_label,
                            min_value=0.0,
                            value=0.0,
                            step=1000.0,
                            key=f"{field}_{i}",
                            help=field_help
                        )
                    elif field == 'PropertyAge':
                        value = st.number_input(
                            field_label,
                            min_value=0,
                            max_value=100,
                            value=0,
                            key=f"{field}_{i}",
                            help=field_help
                        )
                    elif field == 'AnnualGrowthRate':
                        value = st.number_input(
                            field_label,
                            min_value=-20.0,
                            max_value=50.0,
                            value=0.0,
                            step=0.1,
                            key=f"{field}_{i}",
                            help=field_help
                        )
                    else:
                        # Default fallback for any other field types
                        value = st.number_input(
                            field_label,
                            value=0.0,
                            key=f"{field}_{i}",
                            help=field_help
                        )
                    
                    data[field].append(value)
        
        # Submit button
        submitted = st.form_submit_button(get_text("analyze_data"))
        
        if submitted:
            # Create DataFrame
            df = pd.DataFrame(data)
            
            # Validate data
            validator = DataValidator()
            validation_result = validator.validate_manual_data(df, list(required_fields))
            
            if validation_result['valid']:
                st.success(get_text("data_submitted_successfully"))
                return df
            else:
                st.error(get_text("data_validation_failed"))
                for error in validation_result['errors']:
                    st.error(f"• {error}")
                return None
    
    return None

def get_field_label(field):
    """Get localized field label"""
    labels = {
        'TotalIncome': {'en': 'Total Income ($)', 'ar': 'إجمالي الدخل ($)'},
        'Expenses': {'en': 'Expenses ($)', 'ar': 'المصروفات ($)'},
        'PropertyValue': {'en': 'Property Value ($)', 'ar': 'قيمة العقار ($)'},
        'PropertyAge': {'en': 'Property Age (years)', 'ar': 'عمر العقار (سنوات)'},
        'AnnualGrowthRate': {'en': 'Annual Growth Rate (%)', 'ar': 'معدل النمو السنوي (%)'}
    }
    
    lang = st.session_state.language
    return labels.get(field, {}).get(lang, field)

def get_field_help(field):
    """Get localized field help text"""
    help_texts = {
        'TotalIncome': {
            'en': 'Total annual rental income from the property',
            'ar': 'إجمالي الدخل السنوي من الإيجار للعقار'
        },
        'Expenses': {
            'en': 'Total annual expenses (maintenance, taxes, insurance, etc.)',
            'ar': 'إجمالي المصروفات السنوية (صيانة، ضرائب، تأمين، إلخ)'
        },
        'PropertyValue': {
            'en': 'Current market value of the property',
            'ar': 'القيمة السوقية الحالية للعقار'
        },
        'PropertyAge': {
            'en': 'Age of the property in years',
            'ar': 'عمر العقار بالسنوات'
        },
        'AnnualGrowthRate': {
            'en': 'Expected annual appreciation rate of the property',
            'ar': 'معدل الارتفاع السنوي المتوقع في قيمة العقار'
        }
    }
    
    lang = st.session_state.language
    return help_texts.get(field, {}).get(lang, '')
