"""Currency selector component"""

import streamlit as st
from utils.localization import get_text

# Supported currencies
CURRENCIES = {
    'USD': {'symbol': '$', 'name_en': 'US Dollar', 'name_ar': 'دولار أمريكي'},
    'EUR': {'symbol': '€', 'name_en': 'Euro', 'name_ar': 'يورو'},
    'GBP': {'symbol': '£', 'name_en': 'British Pound', 'name_ar': 'جنيه إسترليني'},
    'SAR': {'symbol': 'SAR', 'name_en': 'Saudi Riyal', 'name_ar': 'ريال سعودي'},
    'AED': {'symbol': 'AED', 'name_en': 'UAE Dirham', 'name_ar': 'درهم إماراتي'},
    'CAD': {'symbol': 'CAD', 'name_en': 'Canadian Dollar', 'name_ar': 'دولار كندي'},
    'AUD': {'symbol': 'AUD', 'name_en': 'Australian Dollar', 'name_ar': 'دولار أسترالي'}
}

def currency_selector_component():
    """Component for selecting currency"""
    
    # Initialize currency in session state
    if 'selected_currency' not in st.session_state:
        st.session_state.selected_currency = 'USD'
    
    # Get current language
    lang = st.session_state.get('language', 'en')
    
    # Create currency options for display
    currency_options = {}
    for code, info in CURRENCIES.items():
        display_name = f"{info['symbol']} - {info[f'name_{lang}']}"
        currency_options[display_name] = code
    
    # Currency selector in sidebar
    with st.sidebar:
        st.subheader(get_text("currency_settings"))
        
        # Find current display name
        current_currency = st.session_state.selected_currency
        current_display = None
        for display, code in currency_options.items():
            if code == current_currency:
                current_display = display
                break
        
        # Currency selector
        selected_display = st.selectbox(
            get_text("select_currency"),
            options=list(currency_options.keys()),
            index=list(currency_options.values()).index(current_currency) if current_currency in currency_options.values() else 0,
            help=get_text("currency_help")
        )
        
        # Update session state if currency changed
        new_currency = currency_options[selected_display]
        if new_currency != st.session_state.selected_currency:
            st.session_state.selected_currency = new_currency
            st.rerun()
    
    return st.session_state.selected_currency

def get_currency_symbol(currency_code: str = None) -> str:
    """Get currency symbol for selected currency"""
    
    if currency_code is None:
        currency_code = st.session_state.get('selected_currency', 'USD')
    
    return CURRENCIES.get(currency_code, CURRENCIES['USD'])['symbol']

def format_currency(amount: float, currency_code: str = None) -> str:
    """Format amount with selected currency"""
    
    if currency_code is None:
        currency_code = st.session_state.get('selected_currency', 'USD')
    
    symbol = get_currency_symbol(currency_code)
    
    # Format with appropriate decimal places and thousand separators
    if symbol in ['$', '€', '£']:
        return f"{symbol}{amount:,.2f}"
    else:
        return f"{amount:,.2f} {symbol}"

def get_currency_info(currency_code: str = None) -> dict:
    """Get currency information"""
    
    if currency_code is None:
        currency_code = st.session_state.get('selected_currency', 'USD')
    
    return CURRENCIES.get(currency_code, CURRENCIES['USD'])