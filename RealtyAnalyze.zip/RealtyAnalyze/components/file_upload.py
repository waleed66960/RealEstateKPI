"""File upload component for CSV/Excel files"""

import streamlit as st
import pandas as pd
from utils.localization import get_text
from utils.file_utils import validate_file, create_sample_template
from core.validator import DataValidator
from components.file_validation_feedback import enhanced_file_validation_component

def file_upload_component():
    """Component for file upload functionality"""
    
    st.subheader(get_text("file_upload_title"))
    
    # Download sample template
    col1, col2 = st.columns([1, 1])
    
    with col1:
        if st.button(get_text("download_template")):
            template_data = create_sample_template()
            st.download_button(
                label=get_text("download_excel_template"),
                data=template_data,
                file_name="real_estate_template.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
    
    # File upload
    uploaded_file = st.file_uploader(
        get_text("choose_file"),
        type=['csv', 'xlsx', 'xls'],
        help=get_text("file_upload_help")
    )
    
    if uploaded_file is not None:
        try:
            # Validate file
            if not validate_file(uploaded_file):
                st.error(get_text("invalid_file"))
                return None
            
            # Read file
            if uploaded_file.name.endswith('.csv'):
                df = pd.read_csv(uploaded_file)
            else:
                df = pd.read_excel(uploaded_file)
            
            # Validate data
            validator = DataValidator()
            validation_result = validator.validate_uploaded_data(df)
            
            if validation_result['valid']:
                st.success(get_text("file_uploaded_successfully"))
                
                # Enhanced validation feedback
                enhanced_file_validation_component(uploaded_file, df)
                
                return df
            
            else:
                st.error(get_text("data_validation_failed"))
                for error in validation_result['errors']:
                    st.error(f"• {error}")
                return None
                
        except Exception as e:
            st.error(f"{get_text('file_processing_error')}: {str(e)}")
            return None
    
    return None

def display_column_mapping(df):
    """Display column mapping interface for uploaded data"""
    
    st.subheader(get_text("column_mapping"))
    st.write(get_text("column_mapping_description"))
    
    required_columns = ['TotalIncome', 'Expenses', 'PropertyValue', 'PropertyAge', 'AnnualGrowthRate']
    mapping = {}
    
    for required_col in required_columns:
        mapping[required_col] = st.selectbox(
            f"{get_text('map_column')} {required_col}:",
            options=[''] + list(df.columns),
            key=f"mapping_{required_col}"
        )
    
    return mapping
