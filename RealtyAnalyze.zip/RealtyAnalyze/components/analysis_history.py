"""Analysis history management component"""

import streamlit as st
import json
import os
from datetime import datetime
from typing import Dict, List, Any
from utils.localization import get_text
from database.operations import db_ops

def save_analysis_history(results: Dict[str, Any], selected_kpis: List[str], analysis_name: str = None):
    """Save analysis results to user's history"""
    
    if not st.session_state.get('logged_in', False):
        return False
    
    user_id = st.session_state.get('user_id')
    if not user_id:
        return False
    
    try:
        analysis = db_ops.save_analysis(
            user_id=user_id,
            name=analysis_name or f"Analysis {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            selected_kpis=selected_kpis,
            results=results,
            currency=st.session_state.get('selected_currency', 'USD'),
            language=st.session_state.get('language', 'en'),
            data_source='manual_input',  # This will be updated based on actual source
            property_count=len(results.get('properties', [])) if 'properties' in results else 1
        )
        
        return analysis is not None
        
    except Exception as e:
        st.error(f"Error saving analysis history: {str(e)}")
        return False
    
    finally:
        db_ops.close_session()

def load_user_history(user_id: int) -> List[Dict[str, Any]]:
    """Load user's analysis history"""
    
    try:
        analyses = db_ops.get_user_analyses(user_id, limit=20)
        
        # Convert to the expected format
        history = []
        for analysis in analyses:
            history_entry = {
                'id': analysis.id,
                'timestamp': analysis.created_at.isoformat(),
                'name': analysis.name,
                'selected_kpis': analysis.selected_kpis,
                'results': analysis.results,
                'currency': analysis.currency,
                'language': analysis.language
            }
            history.append(history_entry)
        
        return history
        
    except Exception:
        return []
    
    finally:
        db_ops.close_session()

def analysis_history_component():
    """Component for viewing and managing analysis history"""
    
    if not st.session_state.get('logged_in', False):
        st.info(get_text("login_required_for_history"))
        return
    
    user_id = st.session_state.get('user_id')
    if not user_id:
        return
    
    st.subheader(get_text("analysis_history"))
    
    # Load history
    history = load_user_history(user_id)
    
    if not history:
        st.info(get_text("no_analysis_history"))
        return
    
    # Display history
    st.write(f"{get_text('total_analyses')}: {len(history)}")
    
    # Sort by timestamp (newest first)
    history.sort(key=lambda x: x['timestamp'], reverse=True)
    
    # Create tabs for different views
    tab1, tab2 = st.tabs([get_text("recent_analyses"), get_text("compare_analyses")])
    
    with tab1:
        display_recent_analyses(history)
    
    with tab2:
        display_analysis_comparison(history)

def display_recent_analyses(history: List[Dict[str, Any]]):
    """Display recent analyses"""
    
    for i, entry in enumerate(history[:10]):  # Show last 10
        with st.expander(f"📊 {entry['name']} - {entry['timestamp'][:16]}"):
            
            col1, col2, col3 = st.columns([2, 1, 1])
            
            with col1:
                st.write(f"**{get_text('selected_kpis')}:** {', '.join(entry['selected_kpis'])}")
                st.write(f"**{get_text('currency')}:** {entry.get('currency', 'USD')}")
                st.write(f"**{get_text('language')}:** {entry.get('language', 'en')}")
            
            with col2:
                if st.button(get_text("load_analysis"), key=f"load_{i}"):
                    load_analysis_from_history(entry)
            
            with col3:
                if st.button(get_text("delete_analysis"), key=f"delete_{i}"):
                    delete_analysis_from_history(entry['id'])
            
            # Display key results
            st.subheader(get_text("key_results"))
            
            results_cols = st.columns(min(len(entry['selected_kpis']), 4))
            
            for idx, kpi in enumerate(entry['selected_kpis']):
                if kpi in entry['results']:
                    col = results_cols[idx % len(results_cols)]
                    with col:
                        value = entry['results'][kpi]['value']
                        
                        # Format value based on type
                        if entry['results'][kpi].get('unit') == 'percentage':
                            formatted_value = f"{value:.2f}%"
                        elif entry['results'][kpi].get('unit') == 'USD':
                            currency_symbol = get_currency_symbol(entry.get('currency', 'USD'))
                            formatted_value = f"{currency_symbol}{value:,.2f}"
                        else:
                            formatted_value = f"{value:.2f}"
                        
                        st.metric(kpi.upper(), formatted_value)

def display_analysis_comparison(history: List[Dict[str, Any]]):
    """Display analysis comparison tool"""
    
    if len(history) < 2:
        st.info(get_text("need_multiple_analyses"))
        return
    
    st.write(get_text("select_analyses_to_compare"))
    
    # Create analysis options
    analysis_options = {}
    for entry in history:
        display_name = f"{entry['name']} ({entry['timestamp'][:16]})"
        analysis_options[display_name] = entry
    
    # Multi-select for comparison
    selected_analyses = st.multiselect(
        get_text("select_for_comparison"),
        options=list(analysis_options.keys()),
        max_selections=4
    )
    
    if len(selected_analyses) >= 2:
        # Create comparison table
        comparison_data = []
        
        for analysis_name in selected_analyses:
            entry = analysis_options[analysis_name]
            row_data = {'Analysis': entry['name'], 'Date': entry['timestamp'][:16]}
            
            # Add KPI values
            for kpi in entry['selected_kpis']:
                if kpi in entry['results']:
                    value = entry['results'][kpi]['value']
                    if entry['results'][kpi].get('unit') == 'percentage':
                        row_data[kpi.upper()] = f"{value:.2f}%"
                    elif entry['results'][kpi].get('unit') == 'USD':
                        row_data[kpi.upper()] = f"${value:,.2f}"
                    else:
                        row_data[kpi.upper()] = f"{value:.2f}"
            
            comparison_data.append(row_data)
        
        # Display comparison table
        if comparison_data:
            import pandas as pd
            df = pd.DataFrame(comparison_data)
            st.dataframe(df, use_container_width=True)

def load_analysis_from_history(entry: Dict[str, Any]):
    """Load analysis from history into current session"""
    
    st.session_state.analysis_results = entry['results']
    st.session_state.selected_kpis = entry['selected_kpis']
    
    # Set currency and language if different
    if entry.get('currency') != st.session_state.get('selected_currency'):
        st.session_state.selected_currency = entry.get('currency', 'USD')
    
    if entry.get('language') != st.session_state.get('language'):
        st.session_state.language = entry.get('language', 'en')
    
    st.success(get_text("analysis_loaded"))
    st.rerun()

def delete_analysis_from_history(analysis_id: int):
    """Delete analysis from history"""
    
    user_id = st.session_state.get('user_id')
    if not user_id:
        return
    
    try:
        success = db_ops.delete_analysis(analysis_id, user_id)
        if success:
            st.success(get_text("analysis_deleted"))
            st.rerun()
        else:
            st.error("Failed to delete analysis")
    except Exception as e:
        st.error(f"Error deleting analysis: {str(e)}")
    
    finally:
        db_ops.close_session()

def get_currency_symbol(currency_code: str) -> str:
    """Get currency symbol (fallback if currency_selector not imported)"""
    
    symbols = {
        'USD': '$', 'EUR': '€', 'GBP': '£', 'SAR': 'SAR',
        'AED': 'AED', 'CAD': 'CAD', 'AUD': 'AUD'
    }
    return symbols.get(currency_code, '$')