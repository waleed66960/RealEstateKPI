"""Language selector sidebar component"""

import streamlit as st
from utils.localization import get_text, LANGUAGES

def setup_language_sidebar():
    """Setup language selector in sidebar"""
    
    with st.sidebar:
        st.header("🌍 Language / اللغة")
        
        # Language selector
        language_options = {
            "🇺🇸 English": "en",
            "🇸🇦 العربية": "ar"
        }
        
        current_lang = st.session_state.get('language', 'en')
        current_display = "🇺🇸 English" if current_lang == 'en' else "🇸🇦 العربية"
        
        selected_language_display = st.selectbox(
            "Select Language / اختر اللغة",
            options=list(language_options.keys()),
            index=list(language_options.values()).index(current_lang)
        )
        
        # Update session state if language changed
        new_language = language_options[selected_language_display]
        if new_language != st.session_state.get('language'):
            st.session_state.language = new_language
            st.rerun()
        
        st.divider()
        
        # Display user info if logged in
        if st.session_state.get('logged_in', False):
            st.success(f"👤 {get_text('logged_in_as')}: {st.session_state.get('username', 'User')}")
            
            if st.session_state.get('subscribed', False):
                st.success(f"✅ {get_text('subscription_active')}")
            else:
                st.warning(f"⚠️ {get_text('subscription_required')}")
            
            if st.button(get_text('logout')):
                # Clear session state
                for key in ['logged_in', 'subscribed', 'username', 'user_data', 'analysis_results']:
                    if key in st.session_state:
                        del st.session_state[key]
                st.rerun()
        
        st.divider()
        
        # App information
        st.markdown(f"### {get_text('about_app')}")
        st.markdown(get_text('app_info'))
        
        # Help section
        with st.expander(f"❓ {get_text('help')}"):
            st.markdown(get_text('help_content'))
        
        # Contact information
        st.markdown(f"### {get_text('contact')}")
        st.markdown(get_text('contact_info'))

def display_app_info():
    """Display application information"""
    
    info_text = {
        'en': """
        **Real Estate Financial Analysis Tool**
        
        This application helps you analyze real estate investments by calculating key financial metrics:
        
        - Net Operating Income (NOI)
        - Capitalization Rate  
        - Opportunity Cost
        - Average Property Age
        - Annual Growth Rate
        
        **Features:**
        - Upload CSV/Excel files or enter data manually
        - Select specific KPIs to analyze
        - Get investment recommendations
        - Export results to PDF
        - Bilingual support (English/Arabic)
        """,
        'ar': """
        **أداة تحليل العقارات المالي**
        
        يساعدك هذا التطبيق في تحليل الاستثمارات العقارية من خلال حساب المؤشرات المالية الرئيسية:
        
        - صافي الدخل التشغيلي
        - معدل الرسملة
        - تكلفة الفرصة البديلة
        - متوسط عمر العقار
        - معدل النمو السنوي
        
        **المميزات:**
        - رفع ملفات CSV/Excel أو إدخال البيانات يدوياً
        - اختيار مؤشرات محددة للتحليل
        - الحصول على توصيات الاستثمار
        - تصدير النتائج إلى PDF
        - دعم اللغتين (الإنجليزية/العربية)
        """
    }
    
    lang = st.session_state.get('language', 'en')
    return info_text[lang]
