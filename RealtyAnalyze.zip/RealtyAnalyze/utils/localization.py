"""Localization and translation utilities"""

import streamlit as st

# Language configurations
LANGUAGES = {
    'en': 'English',
    'ar': 'العربية'
}

# Translation dictionary
TRANSLATIONS = {
    # App basic info
    'app_title': {
        'en': '🏠 Real Estate Financial Analysis Tool',
        'ar': '🏠 أداة تحليل العقارات المالي'
    },
    'app_description': {
        'en': 'Analyze your real estate investments with comprehensive financial metrics and get intelligent recommendations.',
        'ar': 'قم بتحليل استثماراتك العقارية باستخدام المؤشرات المالية الشاملة واحصل على توصيات ذكية.'
    },
    'about_app': {
        'en': 'About This App',
        'ar': 'حول هذا التطبيق'
    },
    'app_info': {
        'en': 'Professional real estate analysis tool with bilingual support and comprehensive KPI calculations.',
        'ar': 'أداة تحليل عقاري احترافية مع دعم ثنائي اللغة وحسابات مؤشرات شاملة.'
    },
    
    # Authentication
    'login': {
        'en': 'Login',
        'ar': 'تسجيل الدخول'
    },
    'signup': {
        'en': 'Sign Up',
        'ar': 'إنشاء حساب'
    },
    'login_title': {
        'en': '🔐 User Login',
        'ar': '🔐 تسجيل دخول المستخدم'
    },
    'signup_title': {
        'en': '👤 Create New Account',
        'ar': '👤 إنشاء حساب جديد'
    },
    'username': {
        'en': 'Username',
        'ar': 'اسم المستخدم'
    },
    'password': {
        'en': 'Password',
        'ar': 'كلمة المرور'
    },
    'email_address': {
        'en': 'Email Address',
        'ar': 'البريد الإلكتروني'
    },
    'confirm_password': {
        'en': 'Confirm Password',
        'ar': 'تأكيد كلمة المرور'
    },
    'login_button': {
        'en': 'Login',
        'ar': 'دخول'
    },
    'create_account': {
        'en': 'Create Account',
        'ar': 'إنشاء حساب'
    },
    'logout': {
        'en': 'Logout',
        'ar': 'تسجيل خروج'
    },
    'logged_in_as': {
        'en': 'Logged in as',
        'ar': 'مسجل باسم'
    },
    
    # Subscription
    'subscription_required': {
        'en': 'Subscription Required',
        'ar': 'الاشتراك مطلوب'
    },
    'subscription_active': {
        'en': 'Subscription Active',
        'ar': 'الاشتراك نشط'
    },
    'subscription_title': {
        'en': '💳 Choose Your Subscription Plan',
        'ar': '💳 اختر خطة الاشتراك'
    },
    'subscription_plans': {
        'en': 'Subscription Plans',
        'ar': 'خطط الاشتراك'
    },
    'basic_plan': {
        'en': 'Basic Plan',
        'ar': 'الخطة الأساسية'
    },
    'demo_plan': {
        'en': 'Demo Plan',
        'ar': 'خطة التجربة'
    },
    'enterprise_plan': {
        'en': 'Enterprise Plan',
        'ar': 'خطة المؤسسات'
    },
    'per_month': {
        'en': 'per month',
        'ar': 'شهرياً'
    },
    'free': {
        'en': 'FREE',
        'ar': 'مجاني'
    },
    'demo_only': {
        'en': '(Demo Only)',
        'ar': '(تجربة فقط)'
    },
    'contact_us': {
        'en': 'Contact Us',
        'ar': 'اتصل بنا'
    },
    
    # Data Input
    'data_input_header': {
        'en': '📊 Data Input',
        'ar': '📊 إدخال البيانات'
    },
    'choose_input_method': {
        'en': 'Choose input method:',
        'ar': 'اختر طريقة الإدخال:'
    },
    'file_upload': {
        'en': '📁 Upload File',
        'ar': '📁 رفع ملف'
    },
    'manual_input': {
        'en': '✍️ Manual Input',
        'ar': '✍️ إدخال يدوي'
    },
    'file_upload_title': {
        'en': 'Upload CSV or Excel File',
        'ar': 'رفع ملف CSV أو Excel'
    },
    'manual_input_title': {
        'en': 'Enter Property Data Manually',
        'ar': 'إدخال بيانات العقار يدوياً'
    },
    'download_template': {
        'en': 'Download Template',
        'ar': 'تحميل النموذج'
    },
    'download_excel_template': {
        'en': 'Download Excel Template',
        'ar': 'تحميل نموذج Excel'
    },
    'choose_file': {
        'en': 'Choose a file',
        'ar': 'اختر ملف'
    },
    'file_upload_help': {
        'en': 'Upload CSV or Excel file with property data',
        'ar': 'ارفع ملف CSV أو Excel يحتوي على بيانات العقار'
    },
    
    # KPI Selection
    'metric_selector_title': {
        'en': '📈 Select KPIs to Analyze',
        'ar': '📈 اختر المؤشرات للتحليل'
    },
    'metric_selector_description': {
        'en': 'Choose which financial metrics you want to calculate and analyze:',
        'ar': 'اختر المؤشرات المالية التي تريد حسابها وتحليلها:'
    },
    'select_kpis': {
        'en': 'Select KPIs:',
        'ar': 'اختر المؤشرات:'
    },
    'select_kpis_help': {
        'en': 'Select one or more KPIs to calculate',
        'ar': 'اختر مؤشر واحد أو أكثر للحساب'
    },
    'select_kpis_first': {
        'en': 'Please select KPIs first to determine required fields.',
        'ar': 'يرجى اختيار المؤشرات أولاً لتحديد الحقول المطلوبة.'
    },
    'no_kpis_selected': {
        'en': 'No KPIs selected for analysis.',
        'ar': 'لم يتم اختيار مؤشرات للتحليل.'
    },
    'no_kpis_selected_warning': {
        'en': 'Please select at least one KPI to analyze.',
        'ar': 'يرجى اختيار مؤشر واحد على الأقل للتحليل.'
    },
    'selected_kpis_summary': {
        'en': 'Selected KPIs Summary',
        'ar': 'ملخص المؤشرات المختارة'
    },
    'available_kpis': {
        'en': 'Available KPIs',
        'ar': 'المؤشرات المتاحة'
    },
    'formula': {
        'en': 'Formula',
        'ar': 'المعادلة'
    },
    'required_fields': {
        'en': 'Required Fields',
        'ar': 'الحقول المطلوبة'
    },
    'total_required_fields': {
        'en': 'Total required fields for selected KPIs',
        'ar': 'إجمالي الحقول المطلوبة للمؤشرات المختارة'
    },
    
    # Analysis
    'analysis_header': {
        'en': '🔍 Analysis Results',
        'ar': '🔍 نتائج التحليل'
    },
    'analysis_results': {
        'en': 'Analysis Results',
        'ar': 'نتائج التحليل'
    },
    'key_metrics': {
        'en': 'Key Metrics',
        'ar': 'المؤشرات الرئيسية'
    },
    'visualizations': {
        'en': 'Visualizations',
        'ar': 'المرئيات'
    },
    'investment_recommendations': {
        'en': 'Investment Recommendations',
        'ar': 'توصيات الاستثمار'
    },
    'welcome_message': {
        'en': 'Welcome! You can now access the full analysis features.',
        'ar': 'مرحباً! يمكنك الآن الوصول لجميع ميزات التحليل.'
    },
    
    # Recommendations
    'excellent_investment': {
        'en': 'Excellent Investment',
        'ar': 'استثمار ممتاز'
    },
    'needs_improvement': {
        'en': 'Needs Improvement',
        'ar': 'يحتاج تحسين'
    },
    'weak_investment': {
        'en': 'Weak Investment',
        'ar': 'استثمار ضعيف'
    },
    
    # Export
    'export_options': {
        'en': 'Export Options',
        'ar': 'خيارات التصدير'
    },
    'export_pdf': {
        'en': 'Export to PDF',
        'ar': 'تصدير إلى PDF'
    },
    'export_json': {
        'en': 'Export Data',
        'ar': 'تصدير البيانات'
    },
    'download_pdf_report': {
        'en': 'Download PDF Report',
        'ar': 'تحميل تقرير PDF'
    },
    'download_json_data': {
        'en': 'Download JSON Data',
        'ar': 'تحميل بيانات JSON'
    },
    
    # Form fields
    'number_of_properties': {
        'en': 'Number of Properties',
        'ar': 'عدد العقارات'
    },
    'number_of_properties_help': {
        'en': 'Enter the number of properties to analyze',
        'ar': 'أدخل عدد العقارات المراد تحليلها'
    },
    'property_data_form': {
        'en': 'Property Data Form',
        'ar': 'نموذج بيانات العقار'
    },
    'property': {
        'en': 'Property',
        'ar': 'العقار'
    },
    'analyze_data': {
        'en': 'Analyze Data',
        'ar': 'تحليل البيانات'
    },
    'required_fields_info': {
        'en': 'Required fields based on selected KPIs',
        'ar': 'الحقول المطلوبة بناءً على المؤشرات المختارة'
    },
    
    # Validation messages
    'data_submitted_successfully': {
        'en': 'Data submitted successfully!',
        'ar': 'تم إرسال البيانات بنجاح!'
    },
    'data_validation_failed': {
        'en': 'Data validation failed:',
        'ar': 'فشل في التحقق من البيانات:'
    },
    'file_uploaded_successfully': {
        'en': 'File uploaded successfully!',
        'ar': 'تم رفع الملف بنجاح!'
    },
    'invalid_file': {
        'en': 'Invalid file format',
        'ar': 'تنسيق ملف غير صحيح'
    },
    'file_processing_error': {
        'en': 'Error processing file',
        'ar': 'خطأ في معالجة الملف'
    },
    
    # Data preview
    'data_preview': {
        'en': 'Data Preview',
        'ar': 'معاينة البيانات'
    },
    'data_summary': {
        'en': 'Data Summary',
        'ar': 'ملخص البيانات'
    },
    'total_properties': {
        'en': 'Total Properties',
        'ar': 'إجمالي العقارات'
    },
    'total_columns': {
        'en': 'Total Columns',
        'ar': 'إجمالي الأعمدة'
    },
    'missing_values': {
        'en': 'Missing Values',
        'ar': 'القيم المفقودة'
    },
    
    # Charts
    'kpi_comparison': {
        'en': 'KPI Comparison',
        'ar': 'مقارنة المؤشرات'
    },
    'percentage_metrics': {
        'en': 'Percentage Metrics',
        'ar': 'المؤشرات النسبية'
    },
    'cap_rate_gauge': {
        'en': 'Cap Rate Gauge',
        'ar': 'مقياس معدل الرسملة'
    },
    'metrics': {
        'en': 'Metrics',
        'ar': 'المؤشرات'
    },
    'values': {
        'en': 'Values',
        'ar': 'القيم'
    },
    
    # Help and Support
    'help': {
        'en': 'Help',
        'ar': 'مساعدة'
    },
    'help_content': {
        'en': '''
        **How to use this app:**
        1. Login or create an account
        2. Subscribe to access analysis features
        3. Upload data file or enter manually
        4. Select KPIs to calculate
        5. Review results and recommendations
        ''',
        'ar': '''
        **كيفية استخدام التطبيق:**
        1. سجل الدخول أو أنشئ حساب
        2. اشترك للوصول لميزات التحليل
        3. ارفع ملف البيانات أو أدخلها يدوياً
        4. اختر المؤشرات للحساب
        5. راجع النتائج والتوصيات
        '''
    },
    'contact': {
        'en': 'Contact',
        'ar': 'اتصال'
    },
    'contact_info': {
        'en': 'For support, email: support@realestate-analyzer.com',
        'ar': 'للدعم، راسلنا: support@realestate-analyzer.com'
    },
    
    # Demo credentials
    'demo_credentials': {
        'en': 'Demo Credentials',
        'ar': 'بيانات التجربة'
    },
    'demo_credentials_info': {
        'en': 'Use username: **demo** and password: **demo** for testing',
        'ar': 'استخدم اسم المستخدم: **demo** وكلمة المرور: **demo** للتجربة'
    },
    
    # Error messages
    'invalid_credentials': {
        'en': 'Invalid username or password',
        'ar': 'اسم مستخدم أو كلمة مرور خاطئة'
    },
    'login_successful': {
        'en': 'Login successful!',
        'ar': 'تم تسجيل الدخول بنجاح!'
    },
    'account_created_successfully': {
        'en': 'Account created successfully!',
        'ar': 'تم إنشاء الحساب بنجاح!'
    },
    'please_login': {
        'en': 'Please login with your new account.',
        'ar': 'يرجى تسجيل الدخول بحسابك الجديد.'
    },
    'account_creation_failed': {
        'en': 'Failed to create account. Please try again.',
        'ar': 'فشل في إنشاء الحساب. يرجى المحاولة مرة أخرى.'
    },
    
    # Success messages
    'pdf_generated': {
        'en': 'PDF report generated successfully!',
        'ar': 'تم إنشاء تقرير PDF بنجاح!'
    },
    'json_exported': {
        'en': 'Data exported successfully!',
        'ar': 'تم تصدير البيانات بنجاح!'
    },
    'pdf_generation_error': {
        'en': 'Error generating PDF',
        'ar': 'خطأ في إنشاء PDF'
    },
    
    # Payment
    'payment_methods': {
        'en': 'Payment Methods',
        'ar': 'طرق الدفع'
    },
    'choose_payment_method': {
        'en': 'Choose payment method:',
        'ar': 'اختر طريقة الدفع:'
    },
    'stripe_payment': {
        'en': 'Credit Card (Stripe)',
        'ar': 'بطاقة ائتمان (Stripe)'
    },
    'demo_subscription': {
        'en': 'Demo Subscription (Free)',
        'ar': 'اشتراك تجريبي (مجاني)'
    },
    
    # Currency
    'currency_settings': {
        'en': 'Currency Settings',
        'ar': 'إعدادات العملة'
    },
    'select_currency': {
        'en': 'Select Currency',
        'ar': 'اختر العملة'
    },
    'currency_help': {
        'en': 'Choose the currency for financial calculations',
        'ar': 'اختر العملة للحسابات المالية'
    },
    
    # Analysis History
    'analysis_history': {
        'en': 'Analysis History',
        'ar': 'سجل التحليلات'
    },
    'login_required_for_history': {
        'en': 'Please login to view your analysis history',
        'ar': 'يرجى تسجيل الدخول لعرض سجل التحليلات'
    },
    'no_analysis_history': {
        'en': 'No analysis history found. Complete an analysis to see it here.',
        'ar': 'لا يوجد سجل تحليلات. أكمل تحليلاً لعرضه هنا.'
    },
    'total_analyses': {
        'en': 'Total Analyses',
        'ar': 'إجمالي التحليلات'
    },
    'recent_analyses': {
        'en': 'Recent Analyses',
        'ar': 'التحليلات الحديثة'
    },
    'compare_analyses': {
        'en': 'Compare Analyses',
        'ar': 'مقارنة التحليلات'
    },
    'load_analysis': {
        'en': 'Load',
        'ar': 'تحميل'
    },
    'delete_analysis': {
        'en': 'Delete',
        'ar': 'حذف'
    },
    'key_results': {
        'en': 'Key Results',
        'ar': 'النتائج الرئيسية'
    },
    'need_multiple_analyses': {
        'en': 'You need at least 2 analyses to compare',
        'ar': 'تحتاج لتحليلين على الأقل للمقارنة'
    },
    'select_analyses_to_compare': {
        'en': 'Select analyses to compare:',
        'ar': 'اختر التحليلات للمقارنة:'
    },
    'select_for_comparison': {
        'en': 'Select for comparison',
        'ar': 'اختر للمقارنة'
    },
    'analysis_loaded': {
        'en': 'Analysis loaded successfully!',
        'ar': 'تم تحميل التحليل بنجاح!'
    },
    'analysis_deleted': {
        'en': 'Analysis deleted successfully!',
        'ar': 'تم حذف التحليل بنجاح!'
    },
    
    # File Validation
    'file_validation_results': {
        'en': 'File Validation Results',
        'ar': 'نتائج فحص الملف'
    },
    'file_name': {
        'en': 'File Name',
        'ar': 'اسم الملف'
    },
    'file_size': {
        'en': 'File Size',
        'ar': 'حجم الملف'
    },
    'total_rows': {
        'en': 'Total Rows',
        'ar': 'إجمالي الصفوف'
    },
    'column_analysis': {
        'en': 'Column Analysis',
        'ar': 'تحليل الأعمدة'
    },
    'can_calculate_kpis': {
        'en': 'Can calculate KPIs',
        'ar': 'يمكن حساب المؤشرات'
    },
    'available_kpis_detail': {
        'en': 'Available KPIs Details',
        'ar': 'تفاصيل المؤشرات المتاحة'
    },
    'missing_requirements_for_kpis': {
        'en': 'Missing requirements for KPIs',
        'ar': 'متطلبات مفقودة للمؤشرات'
    },
    'missing_requirements_detail': {
        'en': 'Missing Requirements Details',
        'ar': 'تفاصيل المتطلبات المفقودة'
    },
    'missing_fields': {
        'en': 'Missing fields:',
        'ar': 'الحقول المفقودة:'
    },
    'column_mapping_suggestions': {
        'en': 'Column Mapping Suggestions',
        'ar': 'اقتراحات ربط الأعمدة'
    },
    'column_mapping_suggestions_found': {
        'en': 'Found possible column mappings:',
        'ar': 'تم العثور على اقتراحات ربط أعمدة:'
    },
    'might_be': {
        'en': 'might be:',
        'ar': 'قد يكون:'
    },
    'use_this': {
        'en': 'Use This',
        'ar': 'استخدم هذا'
    },
    'mapped': {
        'en': 'Mapped',
        'ar': 'تم الربط'
    },
    'data_quality_analysis': {
        'en': 'Data Quality Analysis',
        'ar': 'تحليل جودة البيانات'
    },
    'data_errors_found': {
        'en': 'Data errors found',
        'ar': 'تم العثور على أخطاء في البيانات'
    },
    'data_warnings_found': {
        'en': 'Data warnings found',
        'ar': 'تم العثور على تحذيرات في البيانات'
    },
    'data_quality_good': {
        'en': 'Data quality looks good!',
        'ar': 'جودة البيانات جيدة!'
    },
    'data_preview_with_analysis': {
        'en': 'Data Preview with Analysis',
        'ar': 'معاينة البيانات مع التحليل'
    },
    'column_completely_empty': {
        'en': 'Column is completely empty',
        'ar': 'العمود فارغ تماماً'
    },
    'column_mostly_empty': {
        'en': 'Column is mostly empty',
        'ar': 'العمود فارغ في معظمه'
    },
    'column_has_non_numeric': {
        'en': 'Column has non-numeric values',
        'ar': 'العمود يحتوي على قيم غير رقمية'
    },
    'column_has_few_non_numeric': {
        'en': 'Column has few non-numeric values',
        'ar': 'العمود يحتوي على قيم غير رقمية قليلة'
    },
    'property_values_very_low': {
        'en': 'Property values very low',
        'ar': 'قيم العقارات منخفضة جداً'
    },
    'property_values_very_high': {
        'en': 'Property values very high',
        'ar': 'قيم العقارات مرتفعة جداً'
    },
    'negative_property_age': {
        'en': 'Negative property age found',
        'ar': 'تم العثور على أعمار عقارات سالبة'
    },
    'very_old_properties': {
        'en': 'Very old properties found',
        'ar': 'تم العثور على عقارات قديمة جداً'
    },
    
    # New Analysis Tab
    'new_analysis': {
        'en': 'New Analysis',
        'ar': 'تحليل جديد'
    },
    'save_analysis': {
        'en': 'Save Analysis',
        'ar': 'حفظ التحليل'
    },
    'analysis_name': {
        'en': 'Analysis Name',
        'ar': 'اسم التحليل'
    },
    'analysis_saved': {
        'en': 'Analysis saved to history!',
        'ar': 'تم حفظ التحليل في السجل!'
    }
}

def get_text(key: str, **kwargs) -> str:
    """Get localized text for given key"""
    
    language = st.session_state.get('language', 'en')
    
    if key in TRANSLATIONS:
        text = TRANSLATIONS[key].get(language, TRANSLATIONS[key].get('en', key))
        
        # Format with kwargs if provided
        if kwargs:
            try:
                return text.format(**kwargs)
            except:
                return text
        
        return text
    
    return key

def get_available_languages() -> dict:
    """Get available languages"""
    return LANGUAGES

def set_language(language_code: str):
    """Set current language"""
    if language_code in LANGUAGES:
        st.session_state.language = language_code

def get_current_language() -> str:
    """Get current language code"""
    return st.session_state.get('language', 'en')

def is_rtl() -> bool:
    """Check if current language is RTL"""
    return st.session_state.get('language', 'en') == 'ar'
