"""File handling utilities"""

import pandas as pd
import io
from typing import Optional
from config.settings import SAMPLE_DATA_TEMPLATE, MAX_FILE_SIZE, ALLOWED_EXTENSIONS

def validate_file(uploaded_file) -> bool:
    """Validate uploaded file"""
    
    if uploaded_file is None:
        return False
    
    # Check file size
    if uploaded_file.size > MAX_FILE_SIZE:
        return False
    
    # Check file extension
    file_extension = f".{uploaded_file.name.split('.')[-1].lower()}"
    if file_extension not in ALLOWED_EXTENSIONS:
        return False
    
    return True

def create_sample_template() -> bytes:
    """Create sample Excel template with example data"""
    
    # Create DataFrame with sample data
    df = pd.DataFrame(SAMPLE_DATA_TEMPLATE)
    
    # Create Excel file in memory
    output = io.BytesIO()
    
    try:
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            # Write main data
            df.to_excel(writer, sheet_name='Property_Data', index=False)
        
        # Create instructions sheet
        instructions_data = {
            'Field': [
                'TotalIncome',
                'Expenses', 
                'PropertyValue',
                'PropertyAge',
                'AnnualGrowthRate'
            ],
            'Description': [
                'Total annual rental income from the property ($)',
                'Total annual expenses - maintenance, taxes, insurance ($)',
                'Current market value of the property ($)',
                'Age of the property in years',
                'Expected annual appreciation rate of the property (%)'
            ],
            'Example': [
                '50000',
                '15000',
                '500000',
                '10',
                '3.5'
            ]
        }
        
        instructions_df = pd.DataFrame(instructions_data)
        instructions_df.to_excel(writer, sheet_name='Instructions', index=False)
        
        # Create KPI info sheet
        kpi_data = {
            'KPI': [
                'Net Operating Income (NOI)',
                'Capitalization Rate',
                'Opportunity Cost',
                'Average Property Age',
                'Annual Growth Rate'
            ],
            'Formula': [
                'TotalIncome - Expenses',
                '(NOI / PropertyValue) * 100',
                '(PropertyValue * 0.05) - NOI',
                'mean(PropertyAge)',
                'mean(AnnualGrowthRate)'
            ],
            'Required_Fields': [
                'TotalIncome, Expenses',
                'TotalIncome, Expenses, PropertyValue',
                'TotalIncome, Expenses, PropertyValue',
                'PropertyAge',
                'AnnualGrowthRate'
            ]
        }
        
        kpi_df = pd.DataFrame(kpi_data)
        kpi_df.to_excel(writer, sheet_name='KPI_Information', index=False)
    except Exception as e:
        # Fallback: create simple CSV-like template
        df.to_excel(output, index=False)
    
    output.seek(0)
    return output.getvalue()

def read_uploaded_file(uploaded_file) -> Optional[pd.DataFrame]:
    """Read uploaded file and return DataFrame"""
    
    try:
        if uploaded_file.name.endswith('.csv'):
            # Try different encodings for CSV
            try:
                df = pd.read_csv(uploaded_file, encoding='utf-8')
            except UnicodeDecodeError:
                uploaded_file.seek(0)
                df = pd.read_csv(uploaded_file, encoding='latin-1')
        
        elif uploaded_file.name.endswith(('.xlsx', '.xls')):
            df = pd.read_excel(uploaded_file)
        
        else:
            return None
        
        # Clean column names (remove extra spaces, etc.)
        df.columns = df.columns.str.strip()
        
        return df
        
    except Exception as e:
        print(f"Error reading file: {str(e)}")
        return None

def convert_to_csv(df: pd.DataFrame) -> str:
    """Convert DataFrame to CSV string"""
    
    return df.to_csv(index=False)

def convert_to_excel(df: pd.DataFrame) -> bytes:
    """Convert DataFrame to Excel bytes"""
    
    output = io.BytesIO()
    
    try:
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False)
    except Exception:
        # Fallback to CSV in BytesIO
        csv_data = df.to_csv(index=False)
        output.write(csv_data.encode('utf-8'))
    
    output.seek(0)
    return output.getvalue()

def clean_numeric_data(df: pd.DataFrame, numeric_columns: list) -> pd.DataFrame:
    """Clean and convert numeric columns"""
    
    df_cleaned = df.copy()
    
    for col in numeric_columns:
        if col in df_cleaned.columns:
            # Remove currency symbols and commas
            if df_cleaned[col].dtype == 'object':
                df_cleaned[col] = df_cleaned[col].astype(str)
                df_cleaned[col] = df_cleaned[col].str.replace('$', '')
                df_cleaned[col] = df_cleaned[col].str.replace(',', '')
                df_cleaned[col] = df_cleaned[col].str.replace('%', '')
            
            # Convert to numeric, errors='coerce' will convert invalid values to NaN
            df_cleaned[col] = pd.to_numeric(df_cleaned[col], errors='coerce')
    
    return df_cleaned

def get_file_info(uploaded_file) -> dict:
    """Get information about uploaded file"""
    
    if uploaded_file is None:
        return {}
    
    return {
        'name': uploaded_file.name,
        'size': uploaded_file.size,
        'type': uploaded_file.type,
        'size_mb': round(uploaded_file.size / (1024 * 1024), 2)
    }

def format_file_size(size_bytes: int) -> str:
    """Format file size in human readable format"""
    
    if size_bytes == 0:
        return "0 B"
    
    size_names = ["B", "KB", "MB", "GB"]
    
    import math
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    
    return f"{s} {size_names[i]}"

def validate_required_columns(df: pd.DataFrame, required_columns: list) -> dict:
    """Validate that DataFrame contains required columns"""
    
    available_columns = set(df.columns)
    required_columns_set = set(required_columns)
    
    missing_columns = required_columns_set - available_columns
    extra_columns = available_columns - required_columns_set
    
    return {
        'valid': len(missing_columns) == 0,
        'missing_columns': list(missing_columns),
        'extra_columns': list(extra_columns),
        'available_columns': list(available_columns)
    }

def suggest_column_mapping(df: pd.DataFrame, target_columns: list) -> dict:
    """Suggest mapping between uploaded columns and target columns"""
    
    mappings = {}
    df_columns_lower = [col.lower() for col in df.columns]
    
    for target_col in target_columns:
        target_lower = target_col.lower()
        
        # Look for exact matches first
        for i, col in enumerate(df_columns_lower):
            if target_lower in col or col in target_lower:
                mappings[target_col] = df.columns[i]
                break
        
        # Look for partial matches
        if target_col not in mappings:
            for i, col in enumerate(df_columns_lower):
                if any(word in col for word in target_lower.split('_')):
                    mappings[target_col] = df.columns[i]
                    break
    
    return mappings
