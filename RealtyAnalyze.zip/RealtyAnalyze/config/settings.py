"""Application configuration settings"""

import os
from typing import Dict, List

# KPI Configuration
AVAILABLE_KPIS = {
    'noi': {
        'name_en': 'Net Operating Income (NOI)',
        'name_ar': 'صافي الدخل التشغيلي',
        'required_fields': ['TotalIncome', 'Expenses'],
        'formula': 'TotalIncome - Expenses'
    },
    'cap_rate': {
        'name_en': 'Capitalization Rate',
        'name_ar': 'معدل الرسملة',
        'required_fields': ['TotalIncome', 'Expenses', 'PropertyValue'],
        'formula': '(NOI / PropertyValue) * 100'
    },
    'opportunity_cost': {
        'name_en': 'Opportunity Cost',
        'name_ar': 'تكلفة الفرصة البديلة',
        'required_fields': ['PropertyValue', 'TotalIncome', 'Expenses'],
        'formula': '(PropertyValue * 0.05) - NOI'
    },
    'avg_property_age': {
        'name_en': 'Average Property Age',
        'name_ar': 'متوسط عمر العقار',
        'required_fields': ['PropertyAge'],
        'formula': 'mean(PropertyAge)'
    },
    'annual_growth_rate': {
        'name_en': 'Annual Growth Rate',
        'name_ar': 'معدل النمو السنوي',
        'required_fields': ['AnnualGrowthRate'],
        'formula': 'mean(AnnualGrowthRate)'
    }
}

# Investment recommendations based on Cap Rate
CAP_RATE_THRESHOLDS = {
    'excellent': {'min': 8, 'color': 'green', 'emoji': '✅'},
    'needs_improvement': {'min': 5, 'max': 8, 'color': 'orange', 'emoji': '⚠️'},
    'weak': {'max': 5, 'color': 'red', 'emoji': '❌'}
}

# Stripe configuration
STRIPE_PUBLISHABLE_KEY = os.getenv("STRIPE_PUBLISHABLE_KEY", "pk_test_default")
STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY", "sk_test_default")
SUBSCRIPTION_PRICE = 29.99  # USD

# File upload settings
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
ALLOWED_EXTENSIONS = ['.csv', '.xlsx', '.xls']

# Sample data template
SAMPLE_DATA_TEMPLATE = {
    'TotalIncome': [50000, 75000, 120000],
    'Expenses': [15000, 25000, 35000],
    'PropertyValue': [500000, 800000, 1200000],
    'PropertyAge': [10, 5, 15],
    'AnnualGrowthRate': [3.5, 4.2, 2.8]
}
