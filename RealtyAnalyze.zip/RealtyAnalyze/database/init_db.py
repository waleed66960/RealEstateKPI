"""Database initialization script"""

import streamlit as st
from database.models import init_database
from database.operations import db_ops

def initialize_database():
    """Initialize database and create tables"""
    
    try:
        # Initialize database tables
        success = init_database()
        
        if success:
            st.success("Database initialized successfully!")
            
            # Create demo user if it doesn't exist
            demo_user = db_ops.get_user_by_username("demo")
            if not demo_user:
                demo_user = db_ops.create_user(
                    username="demo", 
                    email="demo@example.com", 
                    password="demo"
                )
                
                if demo_user:
                    # Activate demo subscription
                    db_ops.update_user_subscription(
                        user_id=demo_user.id,
                        subscription_type="demo",
                        expires_at=None  # No expiration for demo
                    )
                    st.info("Demo user created with active subscription")
                    
            return True
            
        else:
            st.error("Failed to initialize database")
            return False
            
    except Exception as e:
        st.error(f"Database initialization error: {str(e)}")
        return False
    
    finally:
        db_ops.close_session()

def check_database_connection():
    """Check if database connection is working"""
    
    try:
        # Try to get a user (any user) to test connection
        user = db_ops.get_user_by_username("demo")
        return True
        
    except Exception as e:
        st.error(f"Database connection failed: {str(e)}")
        return False
    
    finally:
        db_ops.close_session()

# Remove auto-initialization to prevent import-time errors