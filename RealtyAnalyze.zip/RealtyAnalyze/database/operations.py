"""Database operations for Real Estate Analyzer"""

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from database.models import User, Property, Analysis, FileUpload, get_session
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
import hashlib
import json

class DatabaseOperations:
    """Database operations manager"""
    
    def __init__(self):
        self.session = None
    
    def get_db_session(self) -> Session:
        """Get database session"""
        if self.session is None:
            self.session = get_session()
        return self.session
    
    def close_session(self):
        """Close database session"""
        if self.session:
            try:
                self.session.close()
            except Exception:
                pass  # Ignore SSL connection errors on close
            finally:
                self.session = None
    
    # User operations
    def create_user(self, username: str, email: str, password: str) -> Optional[User]:
        """Create new user"""
        session = self.get_db_session()
        
        try:
            # Hash password
            password_hash = hashlib.sha256(password.encode()).hexdigest()
            
            user = User(
                username=username,
                email=email,
                password_hash=password_hash
            )
            
            session.add(user)
            session.commit()
            session.refresh(user)
            
            return user
            
        except IntegrityError:
            session.rollback()
            return None
    
    def authenticate_user(self, username: str, password: str) -> Optional[User]:
        """Authenticate user"""
        session = self.get_db_session()
        
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        user = session.query(User).filter(
            User.username == username,
            User.password_hash == password_hash
        ).first()
        
        return user
    
    def get_user_by_username(self, username: str) -> Optional[User]:
        """Get user by username"""
        session = self.get_db_session()
        return session.query(User).filter(User.username == username).first()
    
    def update_user_subscription(self, user_id: int, subscription_type: str, 
                                expires_at: Optional[datetime] = None, 
                                stripe_customer_id: Optional[str] = None) -> bool:
        """Update user subscription"""
        session = self.get_db_session()
        
        try:
            user = session.query(User).filter(User.id == user_id).first()
            if user:
                user.subscription_active = True
                user.subscription_type = subscription_type
                user.subscription_expires = expires_at
                if stripe_customer_id:
                    user.stripe_customer_id = stripe_customer_id
                
                session.commit()
                return True
            return False
            
        except Exception:
            session.rollback()
            return False
    
    def update_user_preferences(self, user_id: int, language: str = None, 
                               currency: str = None) -> bool:
        """Update user preferences"""
        session = self.get_db_session()
        
        try:
            user = session.query(User).filter(User.id == user_id).first()
            if user:
                if language:
                    user.preferred_language = language
                if currency:
                    user.preferred_currency = currency
                
                session.commit()
                return True
            return False
            
        except Exception:
            session.rollback()
            return False
    
    # Property operations
    def save_properties(self, user_id: int, properties_data: List[Dict]) -> bool:
        """Save properties data"""
        session = self.get_db_session()
        
        try:
            # Clear existing properties for this analysis
            session.query(Property).filter(Property.user_id == user_id).delete()
            
            # Add new properties
            for prop_data in properties_data:
                property_obj = Property(
                    user_id=user_id,
                    name=prop_data.get('name'),
                    address=prop_data.get('address'),
                    property_type=prop_data.get('property_type'),
                    total_income=prop_data.get('TotalIncome'),
                    expenses=prop_data.get('Expenses'),
                    property_value=prop_data.get('PropertyValue'),
                    property_age=prop_data.get('PropertyAge'),
                    annual_growth_rate=prop_data.get('AnnualGrowthRate')
                )
                session.add(property_obj)
            
            session.commit()
            return True
            
        except Exception:
            session.rollback()
            return False
    
    def get_user_properties(self, user_id: int) -> List[Property]:
        """Get user properties"""
        session = self.get_db_session()
        return session.query(Property).filter(Property.user_id == user_id).all()
    
    # Analysis operations
    def save_analysis(self, user_id: int, name: str, selected_kpis: List[str], 
                     results: Dict, currency: str, language: str, 
                     data_source: str, property_count: int, 
                     description: str = None) -> Optional[Analysis]:
        """Save analysis"""
        session = self.get_db_session()
        
        try:
            analysis = Analysis(
                user_id=user_id,
                name=name,
                description=description,
                selected_kpis=selected_kpis,
                results=results,
                currency=currency,
                language=language,
                data_source=data_source,
                property_count=property_count
            )
            
            session.add(analysis)
            session.commit()
            session.refresh(analysis)
            
            return analysis
            
        except Exception:
            session.rollback()
            return None
    
    def get_user_analyses(self, user_id: int, limit: int = 20) -> List[Analysis]:
        """Get user analyses"""
        session = self.get_db_session()
        return session.query(Analysis).filter(
            Analysis.user_id == user_id
        ).order_by(Analysis.created_at.desc()).limit(limit).all()
    
    def get_analysis_by_id(self, analysis_id: int, user_id: int) -> Optional[Analysis]:
        """Get analysis by ID"""
        session = self.get_db_session()
        return session.query(Analysis).filter(
            Analysis.id == analysis_id,
            Analysis.user_id == user_id
        ).first()
    
    def delete_analysis(self, analysis_id: int, user_id: int) -> bool:
        """Delete analysis"""
        session = self.get_db_session()
        
        try:
            analysis = session.query(Analysis).filter(
                Analysis.id == analysis_id,
                Analysis.user_id == user_id
            ).first()
            
            if analysis:
                session.delete(analysis)
                session.commit()
                return True
            return False
            
        except Exception:
            session.rollback()
            return False
    
    # File upload tracking
    def log_file_upload(self, user_id: int, filename: str, file_size: int, 
                       file_type: str, rows_processed: int, columns_processed: int,
                       validation_status: str, validation_errors: List = None) -> bool:
        """Log file upload"""
        session = self.get_db_session()
        
        try:
            file_upload = FileUpload(
                user_id=user_id,
                filename=filename,
                file_size=file_size,
                file_type=file_type,
                rows_processed=rows_processed,
                columns_processed=columns_processed,
                validation_status=validation_status,
                validation_errors=validation_errors or []
            )
            
            session.add(file_upload)
            session.commit()
            return True
            
        except Exception:
            session.rollback()
            return False
    
    # Analytics
    def get_user_statistics(self, user_id: int) -> Dict[str, Any]:
        """Get user statistics"""
        session = self.get_db_session()
        
        analyses_count = session.query(Analysis).filter(Analysis.user_id == user_id).count()
        properties_count = session.query(Property).filter(Property.user_id == user_id).count()
        
        recent_analysis = session.query(Analysis).filter(
            Analysis.user_id == user_id
        ).order_by(Analysis.created_at.desc()).first()
        
        return {
            'total_analyses': analyses_count,
            'total_properties': properties_count,
            'last_analysis_date': recent_analysis.created_at if recent_analysis else None,
            'member_since': session.query(User).filter(User.id == user_id).first().created_at
        }

# Global database operations instance
db_ops = DatabaseOperations()