"""Database models for Real Estate Analyzer"""

from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text, Boolean, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy.sql import func
from datetime import datetime
import os

Base = declarative_base()

class User(Base):
    """User model"""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Subscription info
    subscription_active = Column(Boolean, default=False)
    subscription_type = Column(String(50), default='free')
    subscription_expires = Column(DateTime, nullable=True)
    stripe_customer_id = Column(String(100), nullable=True)
    
    # User preferences
    preferred_language = Column(String(10), default='en')
    preferred_currency = Column(String(10), default='USD')
    
    # Relationships
    analyses = relationship("Analysis", back_populates="user", cascade="all, delete-orphan")
    properties = relationship("Property", back_populates="user", cascade="all, delete-orphan")

class Property(Base):
    """Property model"""
    __tablename__ = 'properties'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    
    # Property details
    name = Column(String(200), nullable=True)
    address = Column(String(500), nullable=True)
    property_type = Column(String(100), nullable=True)
    
    # Financial data
    total_income = Column(Float, nullable=True)
    expenses = Column(Float, nullable=True)
    property_value = Column(Float, nullable=True)
    property_age = Column(Integer, nullable=True)
    annual_growth_rate = Column(Float, nullable=True)
    
    # Metadata
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="properties")
    
class Analysis(Base):
    """Analysis model"""
    __tablename__ = 'analyses'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    
    # Analysis details
    name = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    selected_kpis = Column(JSON, nullable=False)
    
    # Results
    results = Column(JSON, nullable=False)
    
    # Configuration
    currency = Column(String(10), default='USD')
    language = Column(String(10), default='en')
    
    # Data source info
    data_source = Column(String(50), nullable=False)  # 'file_upload' or 'manual_input'
    property_count = Column(Integer, nullable=False)
    
    # Metadata
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="analyses")

class FileUpload(Base):
    """File upload tracking"""
    __tablename__ = 'file_uploads'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    
    # File details
    filename = Column(String(500), nullable=False)
    file_size = Column(Integer, nullable=False)
    file_type = Column(String(50), nullable=False)
    
    # Processing info
    rows_processed = Column(Integer, nullable=False)
    columns_processed = Column(Integer, nullable=False)
    validation_status = Column(String(50), nullable=False)
    validation_errors = Column(JSON, nullable=True)
    
    # Metadata
    created_at = Column(DateTime, default=func.now())

# Database configuration
DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://user:password@localhost/realestate_analyzer')

def get_engine():
    """Get database engine"""
    return create_engine(DATABASE_URL)

def get_session():
    """Get database session"""
    engine = get_engine()
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    return SessionLocal()

def create_tables():
    """Create all tables"""
    engine = get_engine()
    Base.metadata.create_all(bind=engine)
    
def drop_tables():
    """Drop all tables (use with caution)"""
    engine = get_engine()
    Base.metadata.drop_all(bind=engine)

def init_database():
    """Initialize database"""
    try:
        create_tables()
        print("Database tables created successfully!")
        return True
    except Exception as e:
        print(f"Error initializing database: {str(e)}")
        return False