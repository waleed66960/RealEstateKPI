"""User signup component"""

import streamlit as st
import json
import re
from datetime import datetime
from auth.login import hash_password, load_users_database, save_users_database
from utils.localization import get_text

def signup_component():
    """User signup form component"""
    
    st.subheader(get_text("signup_title"))
    
    with st.form("signup_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            username = st.text_input(
                get_text("username"),
                placeholder=get_text("choose_username"),
                help=get_text("username_help")
            )
            
            password = st.text_input(
                get_text("password"),
                type="password",
                placeholder=get_text("create_password"),
                help=get_text("password_help")
            )
        
        with col2:
            email = st.text_input(
                get_text("email_address"),
                placeholder=get_text("enter_email"),
                help=get_text("email_help")
            )
            
            confirm_password = st.text_input(
                get_text("confirm_password"),
                type="password",
                placeholder=get_text("confirm_password_placeholder")
            )
        
        # Terms and conditions
        terms_accepted = st.checkbox(
            get_text("accept_terms"),
            help=get_text("terms_help")
        )
        
        # Newsletter subscription
        newsletter = st.checkbox(
            get_text("newsletter_signup"),
            value=False
        )
        
        signup_button = st.form_submit_button(get_text("create_account"))
        
        if signup_button:
            validation_result = validate_signup_data(username, email, password, confirm_password, terms_accepted)
            
            if validation_result['valid']:
                if create_user_account(username, email, password, newsletter):
                    st.success(get_text("account_created_successfully"))
                    st.info(get_text("please_login"))
                else:
                    st.error(get_text("account_creation_failed"))
            else:
                for error in validation_result['errors']:
                    st.error(error)

def validate_signup_data(username: str, email: str, password: str, confirm_password: str, terms_accepted: bool) -> dict:
    """Validate signup form data"""
    
    errors = []
    
    # Username validation
    if not username:
        errors.append(get_text("username_required"))
    elif len(username) < 3:
        errors.append(get_text("username_too_short"))
    elif len(username) > 20:
        errors.append(get_text("username_too_long"))
    elif not re.match("^[a-zA-Z0-9_]+$", username):
        errors.append(get_text("username_invalid_chars"))
    elif user_exists(username):
        errors.append(get_text("username_exists"))
    
    # Email validation
    if not email:
        errors.append(get_text("email_required"))
    elif not is_valid_email(email):
        errors.append(get_text("email_invalid"))
    elif email_exists(email):
        errors.append(get_text("email_exists"))
    
    # Password validation
    if not password:
        errors.append(get_text("password_required"))
    elif len(password) < 6:
        errors.append(get_text("password_too_short"))
    elif password != confirm_password:
        errors.append(get_text("passwords_dont_match"))
    
    # Terms validation
    if not terms_accepted:
        errors.append(get_text("terms_required"))
    
    return {
        'valid': len(errors) == 0,
        'errors': errors
    }

def is_valid_email(email: str) -> bool:
    """Validate email format"""
    
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(email_pattern, email) is not None

def user_exists(username: str) -> bool:
    """Check if username already exists"""
    
    users_db = load_users_database()
    return username in users_db

def email_exists(email: str) -> bool:
    """Check if email already exists"""
    
    users_db = load_users_database()
    
    for user_data in users_db.values():
        if user_data.get('email', '').lower() == email.lower():
            return True
    
    return False

def create_user_account(username: str, email: str, password: str, newsletter: bool = False) -> bool:
    """Create new user account"""
    
    try:
        users_db = load_users_database()
        
        # Create new user data
        user_data = {
            "password": hash_password(password),
            "email": email.lower(),
            "subscribed": False,
            "subscription_date": None,
            "subscription_type": None,
            "created_date": datetime.now().isoformat(),
            "newsletter": newsletter,
            "last_login": None
        }
        
        # Add user to database
        users_db[username] = user_data
        
        # Save database
        save_users_database(users_db)
        
        return True
        
    except Exception as e:
        st.error(f"Error creating account: {str(e)}")
        return False

def display_password_requirements():
    """Display password requirements"""
    
    st.info(get_text("password_requirements"))

def display_terms_and_conditions():
    """Display terms and conditions"""
    
    with st.expander(get_text("terms_and_conditions")):
        st.markdown(get_text("terms_content"))

def display_privacy_policy():
    """Display privacy policy"""
    
    with st.expander(get_text("privacy_policy")):
        st.markdown(get_text("privacy_content"))
