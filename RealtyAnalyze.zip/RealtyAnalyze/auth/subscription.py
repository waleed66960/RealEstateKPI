"""Subscription management component"""

import streamlit as st
import stripe
import os
from datetime import datetime, timedelta
from auth.login import load_users_database, save_users_database
from utils.localization import get_text
from config.settings import STRIPE_PUBLISHABLE_KEY, STRIPE_SECRET_KEY, SUBSCRIPTION_PRICE

# Configure Stripe
stripe.api_key = STRIPE_SECRET_KEY

def subscription_component():
    """Subscription management interface"""
    
    st.subheader(get_text("subscription_title"))
    
    # Display subscription plans
    display_subscription_plans()
    
    # Payment methods
    st.subheader(get_text("payment_methods"))
    
    payment_method = st.radio(
        get_text("choose_payment_method"),
        [get_text("stripe_payment"), get_text("demo_subscription")]
    )
    
    if payment_method == get_text("stripe_payment"):
        stripe_payment_component()
    else:
        demo_subscription_component()

def display_subscription_plans():
    """Display available subscription plans"""
    
    st.subheader(get_text("subscription_plans"))
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown(f"""
        ### {get_text("basic_plan")}
        **${SUBSCRIPTION_PRICE:.2f}** {get_text("per_month")}
        
        ✅ {get_text("unlimited_analysis")}  
        ✅ {get_text("all_kpi_metrics")}  
        ✅ {get_text("pdf_export")}  
        ✅ {get_text("email_support")}
        """)
        
        if st.button(get_text("select_basic"), key="basic_plan"):
            st.session_state.selected_plan = "basic"
    
    with col2:
        st.markdown(f"""
        ### {get_text("demo_plan")}
        **{get_text("free")}** {get_text("demo_only")}
        
        ✅ {get_text("limited_analysis")}  
        ✅ {get_text("sample_data_only")}  
        ❌ {get_text("no_file_upload")}  
        ❌ {get_text("no_export")}
        """)
        
        if st.button(get_text("select_demo"), key="demo_plan"):
            activate_demo_subscription()
    
    with col3:
        st.markdown(f"""
        ### {get_text("enterprise_plan")}
        **{get_text("contact_us")}**
        
        ✅ {get_text("everything_in_basic")}  
        ✅ {get_text("priority_support")}  
        ✅ {get_text("custom_features")}  
        ✅ {get_text("api_access")}
        """)
        
        if st.button(get_text("contact_sales"), key="enterprise_plan"):
            st.info(get_text("enterprise_contact_info"))

def stripe_payment_component():
    """Stripe payment integration"""
    
    st.subheader(get_text("stripe_payment_title"))
    
    # In a real application, you would use Stripe Elements
    # For this demo, we'll simulate the payment process
    
    with st.form("payment_form"):
        st.write(get_text("payment_form_note"))
        
        col1, col2 = st.columns(2)
        
        with col1:
            card_number = st.text_input(
                get_text("card_number"),
                placeholder="4242 4242 4242 4242",
                help=get_text("test_card_info")
            )
            
            cardholder_name = st.text_input(
                get_text("cardholder_name"),
                placeholder=get_text("enter_name")
            )
        
        with col2:
            expiry = st.text_input(
                get_text("expiry_date"),
                placeholder="MM/YY"
            )
            
            cvc = st.text_input(
                get_text("cvc"),
                placeholder="123",
                type="password"
            )
        
        # Billing information
        st.subheader(get_text("billing_information"))
        
        billing_col1, billing_col2 = st.columns(2)
        
        with billing_col1:
            billing_address = st.text_input(get_text("billing_address"))
            billing_city = st.text_input(get_text("city"))
        
        with billing_col2:
            billing_state = st.text_input(get_text("state"))
            billing_zip = st.text_input(get_text("zip_code"))
        
        # Process payment button
        process_payment = st.form_submit_button(
            f"{get_text('pay_now')} ${SUBSCRIPTION_PRICE:.2f}",
            help=get_text("payment_secure_note")
        )
        
        if process_payment:
            if validate_payment_form(card_number, cardholder_name, expiry, cvc):
                # Simulate payment processing
                process_stripe_payment(card_number, cardholder_name, expiry, cvc)
            else:
                st.error(get_text("payment_validation_failed"))

def process_stripe_payment(card_number: str, cardholder_name: str, expiry: str, cvc: str):
    """Process Stripe payment (simulated)"""
    
    # For demo purposes, we'll simulate successful payment for test card
    if card_number.replace(" ", "") == "4242424242424242":
        
        # Simulate payment processing
        with st.spinner(get_text("processing_payment")):
            import time
            time.sleep(2)
        
        # Activate subscription
        activate_subscription("stripe", "basic")
        st.success(get_text("payment_successful"))
        st.rerun()
        
    else:
        st.error(get_text("payment_failed"))
        st.info(get_text("use_test_card"))

def validate_payment_form(card_number: str, cardholder_name: str, expiry: str, cvc: str) -> bool:
    """Validate payment form data"""
    
    errors = []
    
    if not card_number or len(card_number.replace(" ", "")) != 16:
        errors.append(get_text("invalid_card_number"))
    
    if not cardholder_name:
        errors.append(get_text("cardholder_name_required"))
    
    if not expiry or len(expiry) != 5 or "/" not in expiry:
        errors.append(get_text("invalid_expiry"))
    
    if not cvc or len(cvc) != 3:
        errors.append(get_text("invalid_cvc"))
    
    for error in errors:
        st.error(error)
    
    return len(errors) == 0

def demo_subscription_component():
    """Demo subscription activation"""
    
    st.subheader(get_text("demo_subscription_title"))
    
    st.info(get_text("demo_subscription_info"))
    
    if st.button(get_text("activate_demo_subscription")):
        activate_demo_subscription()

def activate_demo_subscription():
    """Activate demo subscription"""
    
    if st.session_state.get('logged_in', False):
        username = st.session_state.get('username')
        
        if username:
            users_db = load_users_database()
            
            if username in users_db:
                users_db[username]['subscribed'] = True
                users_db[username]['subscription_type'] = 'demo'
                users_db[username]['subscription_date'] = datetime.now().isoformat()
                
                save_users_database(users_db)
                
                st.session_state.subscribed = True
                st.session_state.user_data = users_db[username]
                
                st.success(get_text("demo_subscription_activated"))
                st.rerun()
    else:
        st.error(get_text("login_required_for_subscription"))

def activate_subscription(payment_method: str, plan_type: str):
    """Activate paid subscription"""
    
    if st.session_state.get('logged_in', False):
        username = st.session_state.get('username')
        
        if username:
            users_db = load_users_database()
            
            if username in users_db:
                users_db[username]['subscribed'] = True
                users_db[username]['subscription_type'] = plan_type
                users_db[username]['subscription_date'] = datetime.now().isoformat()
                users_db[username]['payment_method'] = payment_method
                
                # Set expiration date (30 days from now)
                expiry_date = datetime.now() + timedelta(days=30)
                users_db[username]['subscription_expiry'] = expiry_date.isoformat()
                
                save_users_database(users_db)
                
                st.session_state.subscribed = True
                st.session_state.user_data = users_db[username]

def check_subscription_status(username: str) -> dict:
    """Check user's subscription status"""
    
    users_db = load_users_database()
    user_data = users_db.get(username, {})
    
    if not user_data.get('subscribed', False):
        return {'active': False, 'reason': 'no_subscription'}
    
    # Check if subscription has expired
    expiry_date = user_data.get('subscription_expiry')
    if expiry_date:
        try:
            expiry = datetime.fromisoformat(expiry_date)
            if datetime.now() > expiry:
                return {'active': False, 'reason': 'expired'}
        except:
            pass
    
    return {
        'active': True,
        'type': user_data.get('subscription_type', 'unknown'),
        'since': user_data.get('subscription_date'),
        'expires': user_data.get('subscription_expiry')
    }

def display_subscription_status():
    """Display current subscription status"""
    
    if st.session_state.get('logged_in', False):
        username = st.session_state.get('username')
        if username:
            status = check_subscription_status(username)
            
            if status['active']:
                st.success(f"{get_text('subscription_active')}: {status['type']}")
                if status.get('expires'):
                    expiry = datetime.fromisoformat(status['expires'])
                    st.info(f"{get_text('expires_on')}: {expiry.strftime('%Y-%m-%d')}")
            else:
                st.warning(get_text('subscription_inactive'))
