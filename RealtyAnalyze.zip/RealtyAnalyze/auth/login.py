"""User login component"""

import streamlit as st
import hashlib
import json
import os
from utils.localization import get_text
from database.operations import db_ops

def login_component():
    """Login form component"""
    
    st.subheader(get_text("login_title"))
    
    with st.form("login_form"):
        username = st.text_input(
            get_text("username"),
            placeholder=get_text("enter_username")
        )
        
        password = st.text_input(
            get_text("password"),
            type="password",
            placeholder=get_text("enter_password")
        )
        
        login_button = st.form_submit_button(get_text("login_button"))
        
        if login_button:
            user = authenticate_user(username, password)
            if user:
                st.session_state.logged_in = True
                st.session_state.username = username
                st.session_state.user_id = user.id
                
                # Check subscription status
                st.session_state.subscribed = user.subscription_active
                
                # Set user preferences
                st.session_state.language = user.preferred_language
                st.session_state.selected_currency = user.preferred_currency

                
                st.success(get_text("login_successful"))
                st.rerun()
            else:
                st.error(get_text("invalid_credentials"))
    
    # Demo credentials info
    with st.expander(get_text("demo_credentials")):
        st.info(get_text("demo_credentials_info"))

def authenticate_user(username: str, password: str):
    """Authenticate user credentials"""
    
    if not username or not password:
        return None
    
    try:
        user = db_ops.authenticate_user(username, password)
        return user
        
    except Exception:
        return None
    
    finally:
        db_ops.close_session()

def hash_password(password: str) -> str:
    """Hash password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def load_users_database() -> dict:
    """Load users database from file"""
    
    users_file = "users_db.json"
    
    if os.path.exists(users_file):
        try:
            with open(users_file, 'r') as f:
                return json.load(f)
        except:
            pass
    
    # Return default database with demo user
    return create_default_users_db()

def create_default_users_db() -> dict:
    """Create default users database"""
    
    default_db = {
        "demo": {
            "password": hash_password("demo"),
            "email": "demo@example.com",
            "subscribed": True,
            "subscription_date": "2024-01-01",
            "subscription_type": "demo"
        }
    }
    
    save_users_database(default_db)
    return default_db

def save_users_database(users_db: dict):
    """Save users database to file"""
    
    try:
        with open("users_db.json", 'w') as f:
            json.dump(users_db, f, indent=2)
    except Exception as e:
        st.error(f"Error saving users database: {str(e)}")

def load_user_data(username: str) -> dict:
    """Load specific user data"""
    
    users_db = load_users_database()
    return users_db.get(username, {})

def create_demo_user():
    """Create demo user with subscription"""
    
    users_db = load_users_database()
    
    if "demo" not in users_db:
        users_db["demo"] = {
            "password": hash_password("demo"),
            "email": "demo@example.com",
            "subscribed": True,
            "subscription_date": "2024-01-01",
            "subscription_type": "demo"
        }
        
        save_users_database(users_db)

def forgot_password_component():
    """Forgot password component"""
    
    st.subheader(get_text("forgot_password"))
    
    with st.form("forgot_password_form"):
        email = st.text_input(
            get_text("email_address"),
            placeholder=get_text("enter_email")
        )
        
        reset_button = st.form_submit_button(get_text("reset_password"))
        
        if reset_button:
            if email:
                # In a real application, this would send an email
                st.info(get_text("password_reset_sent"))
            else:
                st.error(get_text("enter_valid_email"))
